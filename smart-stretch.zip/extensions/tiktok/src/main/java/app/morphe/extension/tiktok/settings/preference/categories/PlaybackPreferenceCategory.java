/*
 * Copyright 2026 Hushfeed contributors
 * https://github.com/SysAdminDoc/hushfeed
 *
 * Built on icysymmetra/tiktok-patches-for-morphe (GPL-3.0).
 */
package app.morphe.extension.tiktok.settings.preference.categories;

import android.content.Context;
import android.preference.PreferenceScreen;
import android.text.InputType;
import app.morphe.extension.shared.settings.BooleanSetting;
import app.morphe.extension.tiktok.settings.Settings;
import app.morphe.extension.tiktok.settings.L10n;
import app.morphe.extension.tiktok.settings.SettingsStatus;
import app.morphe.extension.tiktok.settings.preference.ChoicePreference;
import app.morphe.extension.tiktok.settings.preference.SectionHeadingPreference;
import app.morphe.extension.tiktok.settings.preference.TogglePreference;
import app.morphe.extension.tiktok.settings.preference.InputTextPreference;
import app.morphe.extension.tiktok.settings.preference.NumberInputPreference;
import app.morphe.extension.tiktok.speed.HoldSpeedHud;
import app.morphe.extension.tiktok.speed.PlaybackSpeedPatch;


@SuppressWarnings("deprecation")
public final class PlaybackPreferenceCategory extends ConditionalPreferenceCategory {
    public PlaybackPreferenceCategory(Context context, PreferenceScreen screen) {
        super(context, screen);
        setTitle("Playback");
    }

    /** Whether this page has anything on it. The row into it asks the same question. */
    public static boolean isAvailable() {
        return SettingsStatus.playbackQualityEnabled || SettingsStatus.sdrPlaybackEnabled
                || SettingsStatus.h264PlaybackEnabled || SettingsStatus.playbackSpeedEnabled
                || SettingsStatus.autoAdvanceEnabled || SettingsStatus.videoFitEnabled
                || SettingsStatus.fullScreenHoldEnabled || SettingsStatus.fullScreenNextVideosEnabled
                || SettingsStatus.storyControlsEnabled
                || SettingsStatus.liveControlsEnabled
                || SettingsStatus.feedMuteEnabled || SettingsStatus.keepPulledSoundsEnabled
                || SettingsStatus.backgroundPlayEnabled || SettingsStatus.pictureInPictureEnabled
                || SettingsStatus.showSeekbarEnabled || SettingsStatus.seekbarThumbnailEnabled
                || SettingsStatus.stopVideoLoopingEnabled || SettingsStatus.resumeVideoAfterScrollEnabled
                // The comment sheet switch is a playback switch, and on a bundle with the
                // comment tools and none of the players it is the only thing on this page.
                || SettingsStatus.commentToolsEnabled;
    }

    @Override
    public boolean getSettingsStatus() {
        return isAvailable();
    }

    @Override public void addPreferences(Context context) {
        if (SettingsStatus.autoAdvanceEnabled) {
            addPreference(new SectionHeadingPreference(context, "Auto-advance"));
            addPreference(new TogglePreference(context, "Auto-advance videos",
                    "Move to the next video when the current one ends. Pauses, open dialogs and "
                            + "screen-time holds stop it. Restart TikTok to apply this.",
                    Settings.AUTO_ADVANCE));
            addPreference(new NumberInputPreference(context, "Auto-advance session limit",
                    "Zero means no limit. Counts the videos Hushfeed advanced past for you, "
                            + "not the ones you swiped yourself, and starts again when the feed "
                            + "is rebuilt or you change this number.",
                    Settings.AUTO_ADVANCE_LIMIT, "%1$s video", "%1$s videos").zeroMeansOff());
            addPreference(new TogglePreference(context, "Hide TikTok's Auto scroll button",
                    "Takes TikTok's own Auto scroll action out of the video panel and the Auto "
                            + "scroll label off the top of videos. Tablets and unfolded foldables "
                            + "also lose the Auto scroll switch beside videos. Works with "
                            + "Auto-advance off too.",
                    Settings.AUTO_ADVANCE_HIDE_PANEL_ACTION));
            addPreference(new TogglePreference(context, "Auto-advance in search results",
                    "Also turns on TikTok's own Auto scroll for videos opened from search. "
                            + "Restart TikTok to apply this.",
                    Settings.AUTO_ADVANCE_SEARCH));
        }
        if (SettingsStatus.fullScreenNextVideosEnabled) {
            addPreference(new TogglePreference(context, "Keep the next videos in full screen",
                    "Full screen opens with just your video on most pages, so there's nothing to "
                            + "swipe to. This brings the videos after it along.",
                    Settings.FULL_SCREEN_NEXT_VIDEOS));
        }
        // None of these is auto-advance, and under its heading they read as parts of it: each keeps
        // you on the video you're on, paused behind the comments, held or stopped at its end, or
        // picked up where you left it.
        if (SettingsStatus.commentToolsEnabled || SettingsStatus.fullScreenHoldEnabled
                || SettingsStatus.storyControlsEnabled || SettingsStatus.liveControlsEnabled
                || SettingsStatus.stopVideoLoopingEnabled || SettingsStatus.resumeVideoAfterScrollEnabled) {
            addPreference(new SectionHeadingPreference(context, "Staying on a video"));
        }
        if (SettingsStatus.commentToolsEnabled) {
            addPreference(new TogglePreference(context, "Pause the video while comments are open",
                    "Pauses the video behind the comment sheet while you read. "
                            + "It plays on from the same spot when the sheet closes.",
                    Settings.PAUSE_ON_COMMENTS));
        }
        if (SettingsStatus.fullScreenHoldEnabled) {
            addPreference(new TogglePreference(context, "Stay on the video in full screen",
                    "When a video ends in full screen, stay on it instead of moving to the next "
                            + "one. Swiping still moves on.",
                    Settings.FULL_SCREEN_HOLD));
        }
        if (SettingsStatus.storyControlsEnabled) {
            addPreference(new TogglePreference(context, "Loop a story",
                    "Replay a story from the start when it ends instead of moving to the next one. "
                            + "Tap or swipe to move on.",
                    Settings.STORY_LOOP));
            addPreference(new TogglePreference(context, "Hold a photo story",
                    "Keep a photo story on screen until you tap or swipe, instead of moving on "
                            + "after a few seconds.",
                    Settings.STORY_PHOTO_HOLD));
        }
        if (SettingsStatus.liveControlsEnabled) {
            addPreference(new TogglePreference(context, "Stop LIVE previews opening by themselves",
                    "A LIVE in the feed can count down and take you into the room on its own. "
                            + "This keeps you in the feed until you tap it.",
                    Settings.STOP_LIVE_AUTO_ENTER));
            addPreference(new TogglePreference(context, "Hide the Service+ row under LIVE previews",
                    "A LIVE in the feed can show a Service+ line under the creator's name, such as "
                            + "Ask me anything. This keeps it hidden.",
                    Settings.HIDE_LIVE_SERVICE_PLUS));
            addPreference(new TogglePreference(context, "Hide the summary on LIVE previews",
                    "A LIVE in the feed can show a Summary card that sums up the stream. This keeps "
                            + "it hidden.",
                    Settings.HIDE_LIVE_AI_SUMMARY));
            addPreference(new TogglePreference(context, "Show exact LIVE viewer counts",
                    "A LIVE room shows how many people are watching as a rounded number like 1.2K. "
                            + "This shows the exact count instead.",
                    Settings.SHOW_EXACT_LIVE_VIEWERS));
            addPreference(new TogglePreference(context, "Offer LIVE quality in more rooms",
                    "TikTok lets you pick a LIVE's quality only in some rooms. This adds Video "
                            + "quality to the menu in most of the others, and the next room opens at the quality "
                            + "you picked last.",
                    Settings.OFFER_LIVE_QUALITY));
            addPreference(new TogglePreference(context, "Keep the LIVE quality after TikTok restarts",
                    "TikTok forgets the LIVE quality you picked when it closes. This starts rooms at "
                            + "that quality again after a restart. A room whose stream doesn't have it "
                            + "opens at TikTok's choice.",
                    Settings.REMEMBER_LIVE_QUALITY));
            addPreference(new TogglePreference(context, "Offer Audio only in LIVE quality",
                    "Adds Audio only to a LIVE's Video quality list. The room plays its sound without "
                            + "the picture, which uses much less data, until you pick another quality or "
                            + "leave. Recording from the stream still saves the video.",
                    Settings.LIVE_AUDIO_ONLY));
            addPreference(new TogglePreference(context, "Offer clear screen in every LIVE room",
                    "Clear screen hides a LIVE's chat, gifts and buttons so only the stream shows. "
                            + "TikTok puts it in the menu of only some rooms. This adds it to the others.",
                    Settings.OFFER_LIVE_CLEAR_SCREEN));
            addPreference(new TogglePreference(context, "Keep clear screen in the next LIVE",
                    "A LIVE you swipe to comes back with its chat, gifts and buttons showing. This "
                            + "keeps clear screen on from room to room until you turn it off.",
                    Settings.KEEP_LIVE_CLEAR_SCREEN));
            addPreference(new TogglePreference(context, "Dark LIVE panels in dark mode",
                    "With TikTok in dark mode, a LIVE room still opens its share menu, fan club "
                            + "and other panels in light colors. This opens them dark.",
                    Settings.DARK_LIVE_PANELS));
            addPreference(new TogglePreference(context, "Record LIVEs you watch",
                    "Adds a Record button to LIVE rooms. Tap it to start or stop recording. Leaving the room also stops a recording.",
                    Settings.RECORD_LIVE));
            addPreference(new TogglePreference(context, "Automatically record LIVEs you enter",
                    "Start recording a LIVE's stream when you enter the room. Stop won't restart it "
                            + "until you leave and enter again. Screen recordings still need a tap "
                            + "and Android's permission.",
                    Settings.AUTO_RECORD_LIVE));
            addPreference(new ChoicePreference(context, "LIVE recording quality", Settings.LIVE_RECORD_QUALITY,
                    app.morphe.extension.tiktok.live.LiveRecordQuality.LABELS,
                    app.morphe.extension.tiktok.live.LiveRecordQuality.VALUES)
                    .withNote("Same as the room records the quality you're watching. Highest records "
                            + "the best stream the room has, even while you watch it lower. A number records that "
                            + "quality, or the closest one the room has when it isn't offered."));
            addPreference(new ChoicePreference(context, "LIVE recording source", Settings.LIVE_RECORD_SOURCE,
                    app.morphe.extension.tiktok.live.LiveRecordSource.LABELS,
                    app.morphe.extension.tiktok.live.LiveRecordSource.VALUES)
                    .withNote("Stream only saves the room's own video, as before. Screen records what your "
                            + "phone shows while you watch, with the sound the app plays when TikTok has the "
                            + "microphone permission. Android asks you to allow screen recording each time, and "
                            + "shows its own notice while it records."));
            addPreference(new TogglePreference(context, "Auto tap in LIVE rooms",
                    "Adds an Auto tap button to LIVE rooms. Tap it to send taps to the stream at a steady "
                            + "pace, and tap it again to stop. It also stops when you leave or swipe to "
                            + "another room, leave TikTok or lock the screen.",
                    Settings.LIVE_AUTO_TAP));
            addPreference(new ChoicePreference(context, "Auto tap speed", Settings.LIVE_AUTO_TAP_RATE,
                    app.morphe.extension.tiktok.live.LiveAutoTap.RATE_LABELS,
                    app.morphe.extension.tiktok.live.LiveAutoTap.RATE_VALUES));
        }
        if (SettingsStatus.stopVideoLoopingEnabled) {
            addPreference(new TogglePreference(
                    context,
                    "Stop video looping",
                    "Stop videos at the end instead of replaying them.",
                    Settings.STOP_VIDEO_LOOPING
            ));
        }
        if (SettingsStatus.resumeVideoAfterScrollEnabled) {
            addPreference(new TogglePreference(
                    context,
                    "Resume videos after scrolling",
                    "Continue supported videos from where you stopped when you scroll back to them.",
                    Settings.RESUME_VIDEO_AFTER_SCROLL
            ));
        }
        // How the player itself behaves: the bar, the frame, the sound and what happens when you
        // leave. The bar rows were on App and the frame rows under Quality, which they aren't.
        if (SettingsStatus.showSeekbarEnabled || SettingsStatus.seekbarThumbnailEnabled
                || SettingsStatus.videoFitEnabled || SettingsStatus.feedMuteEnabled
                || SettingsStatus.keepPulledSoundsEnabled || SettingsStatus.backgroundPlayEnabled
                || SettingsStatus.pictureInPictureEnabled) {
            addPreference(new SectionHeadingPreference(context, "Player"));
        }
        if (SettingsStatus.showSeekbarEnabled) {
            addPreference(new TogglePreference(
                    context,
                    "Show the progress bar",
                    "Show TikTok's own progress bar on videos where it's normally hidden.",
                    Settings.SHOW_SEEKBAR
            ));
        }
        if (SettingsStatus.showSeekbarEnabled && SettingsStatus.seekbarExtrasEnabled) {
            addPreference(new TogglePreference(
                    context,
                    "Show the time beside the progress bar",
                    "Show the time played and the video's length at the end of the progress bar "
                            + "while it's on screen.",
                    Settings.SEEKBAR_TIME
            ));
            addPreference(new ChoicePreference(context, "Where the time goes",
                    Settings.SEEKBAR_TIME_PLACEMENT,
                    new String[]{"Beside the bar", "Above the bar"},
                    new String[]{"beside", "above"})
                    .withNote("Above moves the caption and the buttons up a little so the time fits "
                            + "over the right end of the bar. When something else is in the way, the "
                            + "time goes beside the bar."));
            addPreference(new TogglePreference(
                    context,
                    "Full-width progress bar",
                    "Run the progress bar from one screen edge to the other, without the gap "
                            + "TikTok leaves at each end.",
                    Settings.SEEKBAR_FULL_WIDTH
            ));
            addPreference(new TogglePreference(
                    context,
                    "Bigger progress bar handle",
                    "Draw a larger handle and a slightly thicker line on the progress bar, so it's "
                            + "easier to see where you are.",
                    Settings.SEEKBAR_BIG_HANDLE
            ));
        }
        if (SettingsStatus.showSeekbarEnabled && SettingsStatus.storySeekbarEnabled) {
            addPreference(new TogglePreference(
                    context,
                    "Seek bar on video stories",
                    "Add a thin line along the bottom of a video story that you can drag to go "
                            + "back or skip ahead. The time shows while you drag, and a tap on it "
                            + "still moves between stories.",
                    Settings.STORY_SEEKBAR
            ));
        }
        if (SettingsStatus.showSeekbarEnabled && SettingsStatus.soundSeekbarEnabled) {
            addPreference(new TogglePreference(
                    context,
                    "Seek bar on sound previews",
                    "Add a line along the bottom of a sound's cover while its preview plays, with "
                            + "the time played and the preview's length. Tap or drag it to move "
                            + "through the preview.",
                    Settings.SOUND_SEEKBAR
            ));
        }
        if (SettingsStatus.seekbarThumbnailEnabled) {
            addPreference(new TogglePreference(
                    context,
                    "Show the progress bar thumbnail",
                    "Show a video preview thumbnail while dragging the progress bar.",
                    Settings.SHOW_SEEKBAR_THUMBNAIL
            ));
        }
        if (SettingsStatus.videoFitEnabled) {
            TogglePreference fit = new TogglePreference(context, "Fit the video to the screen",
                    "Show the whole video instead of cropping it to the window. Nothing changes "
                            + "on a tall phone, where it already fits. On a folding phone opened "
                            + "up, a squarer screen or a split view the sides or the ends stop "
                            + "being cut off. Photo slideshows get the same treatment on a squarer screen.",
                    Settings.FIT_VIDEO_TO_SCREEN);
            TogglePreference fill = new TogglePreference(context, "Fill the screen with the video",
                    "Crop the video until it covers the whole window. On a tall phone the black "
                            + "strip TikTok leaves under a video goes and so does a little of each side.",
                    Settings.FILL_VIDEO_TO_SCREEN);
            TogglePreference stretch = new TogglePreference(context, "Stretch the video to the screen",
                    "Cover the whole window without cropping anything. The video gets a little "
                            + "taller or wider to do it. A video far from the screen's shape keeps "
                            + "TikTok's size.",
                    Settings.STRETCH_VIDEO_TO_SCREEN);
            TogglePreference smart = new TogglePreference(context, "Smart stretch the video to the screen",
                    "Cover the whole window like Stretch, but keep the middle of the video in its "
                            + "normal shape and spread the stretching toward the top and bottom "
                            + "edges, where the caption and buttons sit. A thin slice is cropped "
                            + "off each side. Needs Android 13 or newer, and on an older phone it "
                            + "acts like Stretch. A video far from the screen's shape keeps "
                            + "TikTok's size.",
                    Settings.SMART_STRETCH_VIDEO_TO_SCREEN);
            // One at a time: each sizes the video its own way, so turning one on turns the rest off.
            TogglePreference[] rows = {fit, fill, stretch, smart};
            BooleanSetting[] switches = {Settings.FIT_VIDEO_TO_SCREEN, Settings.FILL_VIDEO_TO_SCREEN,
                    Settings.STRETCH_VIDEO_TO_SCREEN, Settings.SMART_STRETCH_VIDEO_TO_SCREEN};
            for (int index = 0; index < rows.length; index++) {
                int chosen = index;
                rows[index].setOnPreferenceChangeListener((preference, value) -> {
                    if (Boolean.TRUE.equals(value)) {
                        for (int other = 0; other < rows.length; other++) {
                            if (other == chosen) continue;
                            switches[other].save(false);
                            rows[other].setChecked(false);
                        }
                    }
                    return true;
                });
            }
            addPreference(fit);
            addPreference(fill);
            addPreference(stretch);
            addPreference(smart);
            addPreference(new TogglePreference(context, "Hide the cover picture between videos",
                    "Don't show the still picture TikTok puts up for a moment before each video "
                            + "starts, so the video is the only thing you see as you scroll. The "
                            + "screen can stay dark for a split second until the first frame. "
                            + "Needs Android 13 or newer. Photo posts are left alone.",
                    Settings.HIDE_VIDEO_COVER));
        }
        if (SettingsStatus.feedMuteEnabled) {
            addPreference(new TogglePreference(context, "Mute feed videos",
                    "Play feed videos without sound and leave the phone's volume alone. Music "
                            + "from another app keeps playing while it's on. DMs, stories and LIVE "
                            + "keep their sound.",
                    Settings.FEED_MUTED));
            addPreference(new TogglePreference(context, "Let other apps play until a video starts",
                    "Opening TikTok or your messages no longer pauses music from another app. "
                            + "TikTok takes the sound while a video plays and gives it back when you leave the video.",
                    Settings.FOCUS_WAITS_FOR_VIDEO));
        }
        if (SettingsStatus.keepPulledSoundsEnabled) {
            addPreference(new TogglePreference(context, "Play sounds TikTok pulled",
                    "Play the audio on videos TikTok silenced because their sound was pulled for "
                            + "copyright or in your region. TikTok may still say the sound isn't "
                            + "available.",
                    Settings.KEEP_PULLED_SOUNDS));
        }
        if (SettingsStatus.backgroundPlayEnabled) {
            addPreference(new TogglePreference(context, "Keep playing in the background",
                    "The video you're watching keeps playing to its end after you leave "
                            + "TikTok or turn the screen off, with TikTok's own media notification "
                            + "to pause it. TikTok's background play switch stays on while this is "
                            + "on. Restart TikTok to apply this.",
                    Settings.BACKGROUND_PLAY));
            addPreference(new TogglePreference(context, "Replay in the background",
                    "When a video ends while TikTok plays in the background, it starts over "
                            + "instead of waiting for you to press Play in the notification. A "
                            + "call or another app's sound still pauses it.",
                    Settings.BACKGROUND_REPLAY));
            addPreference(new TogglePreference(context, "Background play in the long-press menu",
                    "Adds TikTok's own background play row to the long-press menu, so you pick it "
                            + "for one video and other videos stop as usual. Has no effect while "
                            + "Keep playing in the background is on. Restart TikTok to apply this.",
                    Settings.BACKGROUND_PLAY_MENU));
        }
        if (SettingsStatus.pictureInPictureEnabled) {
            addPreference(new TogglePreference(context, "Keep watching in a small window",
                    "When you leave TikTok while a video plays, it keeps playing in a small window "
                            + "over your other apps, with buttons to pause it and to go to the previous "
                            + "or next video. Works in the feed and "
                            + "on videos you open from a profile, search or a sound. Needs Android 8 "
                            + "or later.",
                    Settings.PICTURE_IN_PICTURE));
        }

        if (SettingsStatus.playbackSpeedEnabled) {
            addPreference(new SectionHeadingPreference(context, "Speed"));
            addPreference(new TogglePreference(context, "Remember the last speed",
                    "Keep the speed you chose for the next video. Off, each new video "
                            + "starts at 1x and a manual choice lasts for that video only.",
                    Settings.REMEMBER_SPEED));
            addPreference(new TogglePreference(context, "Use a default playback speed",
                    "Start each new video at your default. A manual choice lasts until the video changes.",
                    Settings.DEFAULT_SPEED_ENABLED));
            addPreference(new ChoicePreference(context, "Default playback speed", Settings.DEFAULT_SPEED,
                    new String[]{"0.5x", "0.75x", "1x", "1.25x", "1.5x", "1.75x", "2x", "2.5x", "3x"},
                    new String[]{"0.5", "0.75", "1", "1.25", "1.5", "1.75", "2", "2.5", "3"}));
            String slowest = PlaybackSpeedPatch.speedLabel(PlaybackSpeedPatch.MIN_SPEED);
            String fastest = PlaybackSpeedPatch.speedLabel(PlaybackSpeedPatch.MAX_SPEED);
            InputTextPreference speeds = new InputTextPreference(context, "Speed menu choices",
                    L10n.f(context, "Up to %1$d speeds from %2$s to %3$s, separated by commas. Example: 0.5, 1, 1.5, 2, 2.5, 3. Leave empty for TikTok's list. Restart TikTok to apply this.",
                            PlaybackSpeedPatch.MAX_MENU_SPEEDS, slowest, fastest),
                    Settings.CUSTOM_SPEEDS);
            speeds.withNameKeyboard();
            speeds.withCheck(value -> {
                if (value == null || value.isEmpty()) return null;
                try { PlaybackSpeedPatch.parseMenuSpeeds(value); return null; }
                catch (IllegalArgumentException error) {
                    return L10n.f(context, "Enter up to %1$d comma-separated speeds from %2$s to %3$s",
                            PlaybackSpeedPatch.MAX_MENU_SPEEDS, slowest, fastest);
                }
            });
            speeds.setOnPreferenceChangeListener((preference, value) -> {
                if (value == null || value.toString().isEmpty()) return true;
                try { PlaybackSpeedPatch.parseMenuSpeeds(value.toString()); return true; }
                catch (IllegalArgumentException error) { return false; }
            });
            addPreference(speeds);
            addPreference(new ChoicePreference(context, "Speed while you hold the video", Settings.HOLD_SPEED,
                    new String[]{"1.25x", "1.5x", "1.75x", "2x", "2.5x", "3x"},
                    new String[]{"1.25", "1.5", "1.75", "2", "2.5", "3"}));
            // One speed of the reader's own for the hold and its pull-down lock, no slider (#357).
            InputTextPreference holdCustom = new InputTextPreference(context, "Custom hold speed",
                    L10n.f(context, "One speed from %1$s to %2$s, like 1.8, for the hold and its pull-down lock. It takes the place of the speed above. Leave empty to use that one.",
                            slowest, fastest),
                    Settings.HOLD_SPEED_CUSTOM);
            holdCustom.getEditText().setRawInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            holdCustom.withCheck(value -> value == null || value.trim().isEmpty()
                    || !Float.isNaN(PlaybackSpeedPatch.parseHoldSpeed(value)) ? null
                    : L10n.f(context, "Enter one speed from %1$s to %2$s", slowest, fastest));
            holdCustom.setOnPreferenceChangeListener((preference, value) -> value == null
                    || value.toString().trim().isEmpty()
                    || !Float.isNaN(PlaybackSpeedPatch.parseHoldSpeed(value.toString())));
            addPreference(holdCustom);
            if (SettingsStatus.holdSpeedSlideEnabled) {
                addPreference(new TogglePreference(context, "Slide to change the hold speed",
                        "While you hold a video, slide left or right to step through the speed menu's speeds, "
                                + "and a bubble shows the one you're on. Your next hold starts there. "
                                + "Letting go goes back to normal. A pull-down lock keeps the speed you slid to. "
                                + "On a locked video, letting go locks the new speed.",
                        Settings.HOLD_SPEED_SLIDE));
                addPreference(new ChoicePreference(context, "Hold speed bubble style", Settings.HOLD_SPEED_HUD_STYLE,
                        new String[]{"Pill", "Circle"},
                        new String[]{HoldSpeedHud.PILL, HoldSpeedHud.CIRCLE})
                        .withNote("Pill is the wide bubble with a row of dots under the speed. Circle is a small "
                                + "round dial with a notch for each speed around its edge."));
                if (SettingsStatus.holdSpeedAxisEnabled) {
                    addPreference(new ChoicePreference(context, "Hold speed slide direction", Settings.HOLD_SPEED_SLIDE_AXIS,
                            new String[]{"Sideways", "Up and down"},
                            new String[]{HoldSpeedHud.SIDEWAYS, HoldSpeedHud.UP_DOWN})
                            .withNote("With Sideways, slide left or right to change the speed and pull down to lock it. "
                                    + "With Up and down, slide up for faster and down for slower, and slide to the side "
                                    + "to lock it, so a hold near the edge still reaches every speed."));
                }
            }
            if (SettingsStatus.hideSpeedToastsEnabled) {
                addPreference(new TogglePreference(context, "Hide speed messages",
                        "Hides TikTok's message when you pick a speed from the menu, or lock or unlock one with a hold.",
                        Settings.HIDE_SPEED_TOASTS));
            }
        }
        if (SettingsStatus.playbackQualityEnabled || SettingsStatus.sdrPlaybackEnabled
                || SettingsStatus.h264PlaybackEnabled) {
            addPreference(new SectionHeadingPreference(context, "Quality"));
        }
        if (SettingsStatus.playbackQualityEnabled) {
            addPreference(new ChoicePreference(context, "Video playback quality", Settings.PLAYBACK_QUALITY,
                    new String[]{"Automatic", "Highest", "Lowest", "1080p", "720p", "540p", "480p", "360p"},
                    new String[]{"auto", "highest", "lowest", "1080", "720", "540", "480", "360"}));
            addPreference(new ChoicePreference(context, "On mobile data", Settings.PLAYBACK_QUALITY_METERED,
                    new String[]{"No limit", "Highest", "Lowest", "1080p", "720p", "540p", "480p", "360p"},
                    new String[]{"off", "highest", "lowest", "1080", "720", "540", "480", "360"}));
        }
        if (SettingsStatus.sdrPlaybackEnabled) {
            addPreference(new TogglePreference(context, "Play SDR instead of HDR",
                    "HDR videos light the screen extra bright. This plays the standard (SDR) "
                            + "version instead, so the screen doesn't jump to full brightness. "
                            + "Videos with no standard version still play in HDR.",
                    Settings.PLAY_SDR));
        }
        if (SettingsStatus.h264PlaybackEnabled) {
            addPreference(new TogglePreference(context, "Prefer H.264 video",
                    "Picks the older H.264 video format when TikTok also offers a newer one "
                            + "(HEVC or ByteVC2). It helps phones that stutter or run hot. "
                            + "Videos without an H.264 version still play.",
                    Settings.PREFER_H264));
        }
    }
}
