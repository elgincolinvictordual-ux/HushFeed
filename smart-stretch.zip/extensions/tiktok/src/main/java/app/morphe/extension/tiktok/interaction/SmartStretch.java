/*
 * Copyright 2026 Hushfeed contributors
 * https://github.com/SysAdminDoc/hushfeed
 *
 * Built on icysymmetra/tiktok-patches-for-morphe (GPL-3.0).
 */
package app.morphe.extension.tiktok.interaction;

import android.annotation.TargetApi;
import android.graphics.RenderEffect;
import android.graphics.RuntimeShader;
import android.os.Build;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicLong;

import app.morphe.extension.shared.Logger;
import app.morphe.extension.tiktok.settings.Settings;

/**
 * The non-linear half of "Smart stretch".
 *
 * <p>{@link VideoFit} sizes the video view to the whole window, exactly as Stretch does, which
 * pulls every row of the picture taller by the same amount. This then re-samples the view's own
 * picture through a small shader so the pull is not the same everywhere: the middle of the
 * video keeps its shape, and the stretching is pushed toward the top and bottom edges, where
 * the caption and the buttons already sit. A slice is also cropped off each side, the way a
 * TV's panoramic mode does, so the edges have less to absorb.
 *
 * <p>The shader needs Android 13 (API 33) and a video drawn through a {@code TextureView}. A
 * {@code SurfaceView} is composited on its own and a view effect cannot reach it. Where either
 * is missing nothing here changes the picture, and the video is left as plain Stretch made it.
 */
final class SmartStretch {
    private SmartStretch() {}

    /**
     * The stretch the middle is allowed to keep, as a multiple of the shape the video already
     * has. 1.0 would be a middle with no distortion at all, but the edges would then take up
     * the whole difference.
     */
    static final double MIN_ZOOM = 1.04;

    /**
     * Past this much stretch left over after the crop, the edges would be pulled out so far the
     * curve could not stay increasing, so the crop takes more of the difference instead.
     */
    static final double TARGET_STRETCH = 1.25;

    /** Below this the video is already the window's shape and there is nothing to spread. */
    private static final double NEGLIGIBLE = 1.001;

    /**
     * How tall each row of the picture comes out compared with the video's own shape, when the
     * view is made {@code width} by {@code height} for a video of {@code videoWidth} by
     * {@code videoHeight}. Plain stretch makes it the same number everywhere.
     */
    static double stretchOf(int videoWidth, int videoHeight, int width, int height) {
        if (videoWidth <= 0 || videoHeight <= 0 || width <= 0 || height <= 0) return 1.0;
        return (height / (double) width) / (videoHeight / (double) videoWidth);
    }

    /**
     * The numbers the shader needs: {@code a}, {@code b} and {@code zoom}, or null when there is
     * nothing to spread (the video is not taller than the window's shape).
     *
     * <p>Let {@code t} be a position down the window, 0 at the top and 1 at the bottom, and
     * {@code warp(t)} the position in the stretched picture that is drawn there. The slope of
     * {@code warp} is {@code a - b * (2t - 1)^2}: steepest in the middle, where it equals the
     * stretch left after the crop so the middle comes out with its own shape, and flattening
     * toward the ends, where the picture is spread out more. {@code b} is chosen so that
     * {@code warp(1) = 1}, which is what makes the picture cover the window exactly.
     */
    static double[] curve(int videoWidth, int videoHeight, int width, int height) {
        double stretch = stretchOf(videoWidth, videoHeight, width, height);
        if (stretch <= NEGLIGIBLE) return null;
        double zoom = Math.max(MIN_ZOOM, stretch / TARGET_STRETCH);
        double left = stretch / zoom;
        if (left <= NEGLIGIBLE) {
            // The crop alone covers the difference.
            return new double[]{1.0, 0.0, stretch};
        }
        return new double[]{left, 3.0 * (left - 1.0), zoom};
    }

    /** Where in the stretched picture the row drawn at {@code t} comes from, both as fractions. */
    static double warp(double t, double a, double b) {
        double u = 2.0 * t - 1.0;
        return a * t - b * (u * u * u + 1.0) / 6.0;
    }

    private static final String SHADER =
            "uniform shader content;\n"
                    + "uniform float2 size;\n"
                    + "uniform float a;\n"
                    + "uniform float b;\n"
                    + "uniform float zoom;\n"
                    + "half4 main(float2 p) {\n"
                    + "    float t = clamp(p.y / size.y, 0.0, 1.0);\n"
                    + "    float u = 2.0 * t - 1.0;\n"
                    + "    float y = (a * t - b * (u * u * u + 1.0) / 6.0) * size.y;\n"
                    + "    float x = size.x * 0.5 + (p.x - size.x * 0.5) / zoom;\n"
                    + "    return content.eval(float2(x, y));\n"
                    + "}\n";

    /** What a view carrying the effect was made from, to work it out again when its size changes. */
    private static final class Held implements View.OnLayoutChangeListener {
        final WeakReference<View> view;
        final int videoWidth;
        final int videoHeight;
        int width;
        int height;
        /**
         * The cover pictures beside the video that carry the effect too. The still frame TikTok
         * shows while the next video loads is its own view, and left plain it would sit stretched
         * evenly, then visibly shrink in the middle once the video starts.
         */
        final List<WeakReference<View>> covers = new ArrayList<>();

        Held(View view, int videoWidth, int videoHeight, int width, int height) {
            this.view = new WeakReference<>(view);
            this.videoWidth = videoWidth;
            this.videoHeight = videoHeight;
            this.width = width;
            this.height = height;
        }

        @Override
        public void onLayoutChange(View changed, int left, int top, int right, int bottom,
                                   int oldLeft, int oldTop, int oldRight, int oldBottom) {
            int w = right - left;
            int h = bottom - top;
            if (w <= 0 || h <= 0) return;
            try {
                if (w != width || h != height) {
                    width = w;
                    height = h;
                    put(changed, videoWidth, videoHeight, w, h);
                } else {
                    // The pictures beside the video are laid out in the same pass as the video.
                    // Look again now that they have a size.
                    coversFor(changed, this);
                }
            } catch (Throwable failure) {
                Logger.printException(() -> "Could not update the smart stretch", failure);
            }
        }
    }

    private static final Map<View, Held> HELD = Collections.synchronizedMap(new WeakHashMap<>());

    /** Views the effect was put on, and how many of those had a TextureView or a SurfaceView under them. */
    static final AtomicLong APPLIED = new AtomicLong();
    static final AtomicLong TEXTURE = new AtomicLong();
    static final AtomicLong SURFACE = new AtomicLong();
    static final AtomicLong NEITHER = new AtomicLong();

    /** Whether the phone can run the shader at all. */
    static boolean supported() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU;
    }

    /**
     * Puts the effect on the video view, sized for the view being {@code width} by {@code height},
     * or takes it off when there is nothing to spread. Never throws: a picture left as plain
     * stretch is the fallback for every way this can fail.
     */
    static void apply(View view, int videoWidth, int videoHeight, int width, int height) {
        if (view == null) return;
        try {
            if (!supported()) return;
            Held held = HELD.get(view);
            if (held == null) {
                held = new Held(view, videoWidth, videoHeight, width, height);
                view.addOnLayoutChangeListener(held);
                HELD.put(view, held);
            } else if (held.videoWidth != videoWidth || held.videoHeight != videoHeight) {
                // A recycled view for another video: start over from this one's size.
                view.removeOnLayoutChangeListener(held);
                held = new Held(view, videoWidth, videoHeight, width, height);
                view.addOnLayoutChangeListener(held);
                HELD.put(view, held);
            } else {
                held.width = width;
                held.height = height;
            }
            put(view, videoWidth, videoHeight, width, height);
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not put the smart stretch on the video", failure);
        }
    }

    private static void put(View view, int videoWidth, int videoHeight, int width, int height) {
        double[] curve = curve(videoWidth, videoHeight, width, height);
        if (curve == null) {
            Gpu.remove(view);
            return;
        }
        Gpu.set(view, width, height, curve);
        coversFor(view, HELD.get(view));
        APPLIED.incrementAndGet();
        Surfaces kinds = surfacesUnder(view);
        if (kinds.texture) TEXTURE.incrementAndGet();
        else if (kinds.surface) SURFACE.incrementAndGet();
        else NEITHER.incrementAndGet();
    }

    /** Takes the effect off a view and forgets it. Cheap when nothing was ever put on. */
    static void clear(View view) {
        if (view == null || HELD.isEmpty()) return;
        Held held = HELD.remove(view);
        if (held == null) return;
        try {
            view.removeOnLayoutChangeListener(held);
            if (supported()) {
                Gpu.remove(view);
                removeCovers(held);
            }
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not take the smart stretch off the video", failure);
        }
    }

    /** A description of what sits beside the video, for the diagnostic report. */
    private static volatile String lastBeside = "";

    static String lastBeside() {
        return lastBeside;
    }

    /**
     * Puts the effect on the full-size pictures that share the video's parent, and describes
     * everything beside the video for the report. A picture counts when it is an ImageView that
     * either fills its parent or is already about the size of the video; the buttons, avatars and
     * icons around it are smaller and stay as they are.
     */
    private static void coversFor(View view, Held held) {
        if (held == null || !supported()) return;
        // With the cover hidden it is not drawn, and the hiding is what is on it.
        if (Settings.HIDE_VIDEO_COVER.get()) return;
        ViewParent parent = view.getParent();
        if (!(parent instanceof ViewGroup)) return;
        double[] curve = curve(held.videoWidth, held.videoHeight, held.width, held.height);
        ViewGroup group = (ViewGroup) parent;
        StringBuilder seen = new StringBuilder();
        List<View> chosen = new ArrayList<>();
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);
            if (child == view) continue;
            boolean cover = curve != null && isCover(child, held);
            if (cover) chosen.add(child);
            if (index < 10) {
                if (seen.length() > 0) seen.append(", ");
                seen.append(child.getClass().getSimpleName()).append(' ')
                        .append(child.getWidth()).append('x').append(child.getHeight())
                        .append(cover ? " (warped too)" : "");
            }
        }
        lastBeside = seen.toString();
        // Take it off any that no longer qualify, then put it on the ones that do.
        for (int index = held.covers.size() - 1; index >= 0; index--) {
            View old = held.covers.get(index).get();
            if (old == null) {
                held.covers.remove(index);
            } else if (!chosen.contains(old)) {
                Gpu.remove(old);
                held.covers.remove(index);
            }
        }
        for (View child : chosen) {
            int width = child.getWidth() > 0 ? child.getWidth() : held.width;
            int height = child.getHeight() > 0 ? child.getHeight() : held.height;
            Gpu.set(child, width, height, curve);
            boolean known = false;
            for (WeakReference<View> reference : held.covers) {
                if (reference.get() == child) {
                    known = true;
                    break;
                }
            }
            if (!known) held.covers.add(new WeakReference<>(child));
        }
    }

    private static boolean isCover(View child, Held held) {
        if (!(child instanceof ImageView)) return false;
        ViewGroup.LayoutParams params = child.getLayoutParams();
        if (params != null && params.width == ViewGroup.LayoutParams.MATCH_PARENT
                && params.height == ViewGroup.LayoutParams.MATCH_PARENT) {
            return true;
        }
        int width = child.getWidth();
        int height = child.getHeight();
        return width >= held.width * 0.95 && height >= held.height * 0.95;
    }

    private static void removeCovers(Held held) {
        for (WeakReference<View> reference : held.covers) {
            View cover = reference.get();
            if (cover != null) Gpu.remove(cover);
        }
        held.covers.clear();
    }

    /** Whether the view has a TextureView or a SurfaceView somewhere under it. */
    static final class Surfaces {
        boolean texture;
        boolean surface;
    }

    static Surfaces surfacesUnder(View view) {
        Surfaces found = new Surfaces();
        look(view, found, 0);
        return found;
    }

    private static void look(View view, Surfaces found, int depth) {
        if (view instanceof TextureView) found.texture = true;
        else if (view instanceof SurfaceView) found.surface = true;
        if (depth > 8 || !(view instanceof ViewGroup)) return;
        ViewGroup group = (ViewGroup) view;
        for (int index = 0; index < group.getChildCount(); index++) {
            look(group.getChildAt(index), found, depth + 1);
        }
    }

    /** The calls that need API 33, kept where nothing loads them on an older phone. */
    @TargetApi(Build.VERSION_CODES.TIRAMISU)
    private static final class Gpu {
        static void set(View view, int width, int height, double[] curve) {
            RuntimeShader shader = new RuntimeShader(SHADER);
            shader.setFloatUniform("size", (float) width, (float) height);
            shader.setFloatUniform("a", (float) curve[0]);
            shader.setFloatUniform("b", (float) curve[1]);
            shader.setFloatUniform("zoom", (float) curve[2]);
            view.setRenderEffect(RenderEffect.createRuntimeShaderEffect(shader, "content"));
        }

        static void remove(View view) {
            view.setRenderEffect(null);
        }
    }
}
