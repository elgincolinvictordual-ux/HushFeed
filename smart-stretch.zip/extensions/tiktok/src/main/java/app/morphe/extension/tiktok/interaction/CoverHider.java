/*
 * Copyright 2026 Hushfeed contributors
 * https://github.com/SysAdminDoc/hushfeed
 *
 * Built on icysymmetra/tiktok-patches-for-morphe (GPL-3.0).
 */
package app.morphe.extension.tiktok.interaction;

import android.annotation.TargetApi;
import android.graphics.RenderEffect;
import android.graphics.RuntimeShader;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicLong;

import app.morphe.extension.shared.Logger;

/**
 * Stops the still picture TikTok puts up for a moment before each video starts from being drawn,
 * so the video is the only thing on screen as you scroll.
 *
 * <p>The picture is a full-size image view beside the video, or inside the view that holds it.
 * It is not removed or hidden, because TikTok shows, fades and hides it on its own schedule and
 * would undo anything written to its visibility or alpha. It is given a view effect that draws
 * nothing instead, which TikTok never touches, and everything TikTok does with the view carries
 * on as before.
 *
 * <p>Only a view with a video surface under it is looked at, so a photo post, whose picture is
 * the post, is left alone. Needs Android 13 (API 33), like {@link SmartStretch}; on an older
 * phone nothing here changes.
 */
final class CoverHider {
    private CoverHider() {}

    private static final String SHADER =
            "uniform shader content;\n"
                    + "half4 main(float2 p) {\n"
                    + "    return content.eval(p) * 0.0;\n"
                    + "}\n";

    /** The pictures made invisible beside one video view, found again at each layout pass. */
    private static final class Held implements View.OnLayoutChangeListener {
        final List<WeakReference<View>> hidden = new ArrayList<>();

        @Override
        public void onLayoutChange(View video, int left, int top, int right, int bottom,
                                   int oldLeft, int oldTop, int oldRight, int oldBottom) {
            try {
                rescan(video, this);
            } catch (Throwable failure) {
                Logger.printException(() -> "Could not hide the cover picture", failure);
            }
        }
    }

    private static final Map<View, Held> HELD = Collections.synchronizedMap(new WeakHashMap<>());

    /** Pictures made invisible so far, and what sat around the last video, for the report. */
    static final AtomicLong HIDDEN = new AtomicLong();
    private static volatile String lastSeen = "";

    static String lastSeen() {
        return lastSeen;
    }

    /** Looks for the cover beside this video view and hides it. Never throws. */
    static void apply(View video) {
        if (video == null) return;
        try {
            if (!SmartStretch.supported()) return;
            Held held = HELD.get(video);
            if (held == null) {
                held = new Held();
                video.addOnLayoutChangeListener(held);
                HELD.put(video, held);
            }
            rescan(video, held);
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not hide the cover picture", failure);
        }
    }

    /** Gives the pictures back their drawing. Cheap when nothing was ever hidden. */
    static void clear(View video) {
        if (video == null || HELD.isEmpty()) return;
        Held held = HELD.remove(video);
        if (held == null) return;
        try {
            video.removeOnLayoutChangeListener(held);
            if (!SmartStretch.supported()) return;
            for (WeakReference<View> reference : held.hidden) {
                View cover = reference.get();
                if (cover != null) Gpu.show(cover);
            }
            held.hidden.clear();
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not bring the cover picture back", failure);
        }
    }

    private static void rescan(View video, Held held) {
        Surfaces surfaces = surfaces(video);
        StringBuilder seen = new StringBuilder();
        List<View> found = new ArrayList<>();
        ViewParent parent = video.getParent();
        if (parent instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) parent;
            collect(group, video, group.getWidth(), group.getHeight(), found, seen, "beside");
        }
        if (video instanceof ViewGroup) {
            ViewGroup inside = (ViewGroup) video;
            collect(inside, null, video.getWidth(), video.getHeight(), found, seen, "inside");
        }
        lastSeen = (surfaces.any() ? "" : "no video surface under it, so left alone; ") + seen;
        if (!surfaces.any()) {
            // A photo post, or a video whose surface is not there yet: nothing is hidden for it.
            for (WeakReference<View> reference : held.hidden) {
                View cover = reference.get();
                if (cover != null) Gpu.show(cover);
            }
            held.hidden.clear();
            return;
        }
        for (View cover : found) {
            boolean known = false;
            for (WeakReference<View> reference : held.hidden) {
                if (reference.get() == cover) {
                    known = true;
                    break;
                }
            }
            if (known) continue;
            Gpu.hide(cover);
            held.hidden.add(new WeakReference<>(cover));
            HIDDEN.incrementAndGet();
        }
    }

    private static void collect(ViewGroup group, View skip, int referenceWidth, int referenceHeight,
                                List<View> found, StringBuilder seen, String where) {
        for (int index = 0; index < group.getChildCount(); index++) {
            View child = group.getChildAt(index);
            if (child == skip) continue;
            boolean cover = isCover(child, referenceWidth, referenceHeight);
            if (cover) found.add(child);
            if (found.size() + seen.length() < 400) {
                if (seen.length() > 0) seen.append(", ");
                seen.append(where).append(' ').append(child.getClass().getSimpleName()).append(' ')
                        .append(child.getWidth()).append('x').append(child.getHeight())
                        .append(cover ? " (hidden)" : "");
            }
        }
    }

    /** A full-size image view: one that fills its parent, or is already about the size of the space. */
    private static boolean isCover(View child, int referenceWidth, int referenceHeight) {
        if (!(child instanceof ImageView)) return false;
        ViewGroup.LayoutParams params = child.getLayoutParams();
        if (params != null && params.width == ViewGroup.LayoutParams.MATCH_PARENT
                && params.height == ViewGroup.LayoutParams.MATCH_PARENT) {
            return true;
        }
        return referenceWidth > 0 && referenceHeight > 0
                && child.getWidth() >= referenceWidth * 0.95
                && child.getHeight() >= referenceHeight * 0.95;
    }

    private static Surfaces surfaces(View video) {
        SmartStretch.Surfaces kinds = SmartStretch.surfacesUnder(video);
        return new Surfaces(kinds.texture || kinds.surface);
    }

    private static final class Surfaces {
        private final boolean present;

        Surfaces(boolean present) {
            this.present = present;
        }

        boolean any() {
            return present;
        }
    }

    /** The calls that need API 33, kept where nothing loads them on an older phone. */
    @TargetApi(Build.VERSION_CODES.TIRAMISU)
    private static final class Gpu {
        static void hide(View view) {
            view.setRenderEffect(RenderEffect.createRuntimeShaderEffect(new RuntimeShader(SHADER), "content"));
        }

        static void show(View view) {
            view.setRenderEffect(null);
        }
    }
}
