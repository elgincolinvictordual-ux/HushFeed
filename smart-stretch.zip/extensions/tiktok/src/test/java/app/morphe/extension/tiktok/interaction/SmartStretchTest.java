package app.morphe.extension.tiktok.interaction;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/** The numbers behind Smart stretch: where each row of the window is drawn from. */
public class SmartStretchTest {

    /** A 9:16 video on a 20:9 phone, made the window's size the way stretch does. */
    private static final int VIDEO_WIDTH = 1080;
    private static final int VIDEO_HEIGHT = 1920;
    private static final int WIDTH = 1080;
    private static final int HEIGHT = 2400;

    @Test
    public void a_video_already_the_windows_shape_has_nothing_to_spread() {
        assertNull(SmartStretch.curve(1080, 2400, 1080, 2400));
    }

    @Test
    public void the_curve_covers_the_window_exactly() {
        double[] curve = SmartStretch.curve(VIDEO_WIDTH, VIDEO_HEIGHT, WIDTH, HEIGHT);
        assertNotNull(curve);
        // The top row comes from the top, the bottom row from the bottom, the middle from the middle.
        assertEquals(0.0, SmartStretch.warp(0.0, curve[0], curve[1]), 1e-9);
        assertEquals(1.0, SmartStretch.warp(1.0, curve[0], curve[1]), 1e-9);
        assertEquals(0.5, SmartStretch.warp(0.5, curve[0], curve[1]), 1e-9);
    }

    @Test
    public void the_curve_only_ever_moves_forward() {
        double[] curve = SmartStretch.curve(VIDEO_WIDTH, VIDEO_HEIGHT, WIDTH, HEIGHT);
        assertNotNull(curve);
        double before = -1;
        for (int step = 0; step <= 100; step++) {
            double at = SmartStretch.warp(step / 100.0, curve[0], curve[1]);
            assertTrue("went backwards at " + step, at > before);
            before = at;
        }
    }

    @Test
    public void the_middle_keeps_its_shape_and_the_edges_take_the_stretch() {
        double[] curve = SmartStretch.curve(VIDEO_WIDTH, VIDEO_HEIGHT, WIDTH, HEIGHT);
        assertNotNull(curve);
        double stretch = SmartStretch.stretchOf(VIDEO_WIDTH, VIDEO_HEIGHT, WIDTH, HEIGHT);
        double zoom = curve[2];
        // How tall a row is drawn compared with the video's own shape, from the slope of the curve.
        double middle = stretch / (zoom * slope(curve, 0.5));
        double edge = stretch / (zoom * slope(curve, 0.0));
        assertEquals("the middle is not stretched", 1.0, middle, 1e-6);
        assertTrue("the edge takes the stretch", edge > 1.5);
        // The crop is a slice, not a chunk.
        assertTrue(zoom >= SmartStretch.MIN_ZOOM && zoom < 1.12);
    }

    @Test
    public void a_slightly_taller_window_is_covered_by_the_crop_alone() {
        double[] curve = SmartStretch.curve(1000, 2000, 1000, 2040);
        assertNotNull(curve);
        assertEquals(0.0, curve[1], 1e-12);
        assertEquals(1.02, curve[2], 1e-9);
    }

    @Test
    public void smart_stretch_takes_what_stretch_takes_inside_its_own_limit() {
        // 9:16 on 20:9 is about a quarter off.
        assertTrue(VideoFit.wants(VideoFit.Mode.SMART, 1080, 1920, 1080, 2400));
        // A 3:4 video on that phone is two thirds off: stretch takes it, smart stretch leaves it.
        assertTrue(VideoFit.wants(VideoFit.Mode.STRETCH, 1080, 1440, 1080, 2400));
        assertFalse(VideoFit.wants(VideoFit.Mode.SMART, 1080, 1440, 1080, 2400));
        // Already the window's size: nothing to do. A wide video is never taken.
        assertFalse(VideoFit.wants(VideoFit.Mode.SMART, 1080, 2400, 1080, 2400));
        assertFalse(VideoFit.wants(VideoFit.Mode.SMART, 1920, 1080, 1080, 2400));
    }

    @Test
    public void smart_stretch_sizes_the_view_the_way_stretch_does() {
        assertEquals(VideoFit.widthFor(VideoFit.Mode.STRETCH, 1080, 1920, 1080, 2400),
                VideoFit.widthFor(VideoFit.Mode.SMART, 1080, 1920, 1080, 2400));
        assertEquals(VideoFit.heightFor(VideoFit.Mode.STRETCH, 1080, 1920, 1080, 2400),
                VideoFit.heightFor(VideoFit.Mode.SMART, 1080, 1920, 1080, 2400));
    }

    private static double slope(double[] curve, double t) {
        double h = 1e-5;
        double low = Math.max(0.0, t - h);
        double high = Math.min(1.0, t + h);
        return (SmartStretch.warp(high, curve[0], curve[1])
                - SmartStretch.warp(low, curve[0], curve[1])) / (high - low);
    }
}
