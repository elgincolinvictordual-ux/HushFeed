#!/usr/bin/env python3
"""Adds Smart stretch and Hide cover to a HushFeed checkout by editing the files in place.

Run from the repository root. Every edit is anchored on text that is already there and is
skipped when it has been applied before, so the script can run twice. A file that has changed
so much that an anchor is gone stops the script with a message instead of being half edited.
"""
import json
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
EXT = "extensions/tiktok/src/main/java/app/morphe/extension/tiktok/"
TEST = "extensions/tiktok/src/test/java/app/morphe/extension/tiktok/"
failed = []


def read(path):
    with open(path, encoding="utf-8") as handle:
        return handle.read()


def write(path, text):
    with open(path, "w", encoding="utf-8", newline="") as handle:
        handle.write(text)


def edit(path, old, new, marker=None, optional=False):
    text = read(path)
    if marker is not None and marker in text:
        return
    if text.count(old) != 1:
        if optional:
            return
        failed.append("%s: expected one match for: %s (found %d)" % (path, old[:70].replace("\n", "\\n"), text.count(old)))
        return
    write(path, text.replace(old, new))


# Already applied (by an earlier run, or committed to the fork): nothing to do.
_fit = EXT + "interaction/VideoFit.java"
if os.path.exists(_fit) and "EdgeWarp.apply(" in read(_fit) and os.path.exists(EXT + "interaction/EdgeWarp.java"):
    print("Smart stretch already applied.")
    sys.exit(0)

# ---------------------------------------------------------------- new files
shutil.copyfile(os.path.join(HERE, "files", "main", "interaction/CoverHider.java"), EXT + "interaction/CoverHider.java")
shutil.copyfile(os.path.join(HERE, "files", "main", "interaction/EdgeWarp.java"), EXT + "interaction/EdgeWarp.java")
shutil.copyfile(os.path.join(HERE, "files", "test", "interaction/SmartZoomTest.java"), TEST + "interaction/SmartZoomTest.java")
shutil.copyfile(os.path.join(HERE, "files", "test", "interaction/EdgeWarpTest.java"), TEST + "interaction/EdgeWarpTest.java")
# An earlier version of this script added classes that are gone now.
for stale in (EXT + "interaction/SmartStretch.java", EXT + "interaction/FlashRecorder.java",
              TEST + "interaction/SmartStretchTest.java"):
    if os.path.exists(stale):
        os.remove(stale)

# ---------------------------------------------------------------- Settings.java
edit(EXT + "settings/Settings.java",
     '''    public static final BooleanSetting STRETCH_VIDEO_TO_SCREEN =
            new BooleanSetting("stretch_video_to_screen", FALSE);
''',
     '''    public static final BooleanSetting STRETCH_VIDEO_TO_SCREEN =
            new BooleanSetting("stretch_video_to_screen", FALSE);
    /**
     * Cover the window with half the difference taken by cropping a thin slice off each side and
     * half by stretching the picture a little, so neither shows much.
     */
    public static final BooleanSetting SMART_STRETCH_VIDEO_TO_SCREEN =
            new BooleanSetting("smart_stretch_video_to_screen", FALSE);
    /** Don't draw the still cover picture TikTok shows for a moment before each video starts. */
    public static final BooleanSetting HIDE_VIDEO_COVER =
            new BooleanSetting("hide_video_cover", FALSE);
''', marker="SMART_STRETCH_VIDEO_TO_SCREEN")

# ---------------------------------------------------------------- the settings page
page = EXT + "settings/preference/categories/PlaybackPreferenceCategory.java"
edit(page,
     '''            // One at a time: each sizes the video its own way, so turning one on turns the rest off.
            TogglePreference[] rows = {fit, fill, stretch};
            BooleanSetting[] switches = {Settings.FIT_VIDEO_TO_SCREEN, Settings.FILL_VIDEO_TO_SCREEN,
                    Settings.STRETCH_VIDEO_TO_SCREEN};''',
     '''            TogglePreference smart = new TogglePreference(context, "Smart stretch the video to the screen",
                    "Cover the whole window by splitting the difference: a thin slice is cropped "
                            + "off each side and the picture is stretched a little, about half and "
                            + "half, so neither shows much. A video far from the screen's shape "
                            + "keeps TikTok's size.",
                    Settings.SMART_STRETCH_VIDEO_TO_SCREEN);
            // One at a time: each sizes the video its own way, so turning one on turns the rest off.
            TogglePreference[] rows = {fit, fill, stretch, smart};
            BooleanSetting[] switches = {Settings.FIT_VIDEO_TO_SCREEN, Settings.FILL_VIDEO_TO_SCREEN,
                    Settings.STRETCH_VIDEO_TO_SCREEN, Settings.SMART_STRETCH_VIDEO_TO_SCREEN};''',
     marker="Settings.SMART_STRETCH_VIDEO_TO_SCREEN};")
edit(page,
     '''            addPreference(stretch);
        }''',
     '''            addPreference(stretch);
            addPreference(smart);
            addPreference(new TogglePreference(context, "Hide the cover picture between videos",
                    "Don't show the still picture TikTok puts up for a moment before each video "
                            + "starts, so the video is the only thing you see as you scroll. The "
                            + "screen can stay dark for a split second until the first frame. "
                            + "Needs Android 13 or newer. Photo posts are left alone.",
                    Settings.HIDE_VIDEO_COVER));
        }''', marker="Settings.HIDE_VIDEO_COVER));")

# ---------------------------------------------------------------- VideoFit.java
fit = EXT + "interaction/VideoFit.java"
text = read(fit)
text = re.sub(r"static final double MAX_STRETCH = [^;]+;", "static final double MAX_STRETCH = 2.0;", text)
write(fit, text)
edit(fit, "enum Mode { LEAVE_ALONE, FIT, FILL, STRETCH }", "enum Mode { LEAVE_ALONE, FIT, FILL, STRETCH, SMART }", marker="STRETCH, SMART }")
edit(fit, '''        if (Settings.STRETCH_VIDEO_TO_SCREEN.get()) return Mode.STRETCH;
        return Mode.LEAVE_ALONE;''', '''        if (Settings.STRETCH_VIDEO_TO_SCREEN.get()) return Mode.STRETCH;
        if (Settings.SMART_STRETCH_VIDEO_TO_SCREEN.get()) return Mode.SMART;
        return Mode.LEAVE_ALONE;''', marker="Settings.SMART_STRETCH_VIDEO_TO_SCREEN.get()) return")
edit(fit, "return mode == Mode.FILL || mode == Mode.STRETCH;", "return mode == Mode.FILL || mode == Mode.STRETCH || mode == Mode.SMART;", marker="mode == Mode.STRETCH || mode == Mode.SMART;\n    }")
edit(fit, '''    // ---------------------------------------------------------------------------------------
    // A fit worked out against a space that then changed size.''', '''    /** The cover picture is hidden or given back whatever the fit switches say. */
    private static void hideCover(View view) {
        if (Settings.HIDE_VIDEO_COVER.get()) CoverHider.apply(view);
        else CoverHider.clear(view);
    }

    // ---------------------------------------------------------------------------------------
    // A fit worked out against a space that then changed size.''', marker="private static void hideCover(")
edit(fit, '''        if (view == null || result == null) return result;
        try {
            // The switches before the reads''', '''        if (view == null || result == null) return result;
        try {
            hideCover(view);
            // The switches before the reads''', marker="hideCover(view);\n            // The switches")
edit(fit, '''        LAST.remove();
        if (view == null || result == null) return LEAVE;
        try {
            Mode mode = mode();''', '''        LAST.remove();
        if (view == null || result == null) return LEAVE;
        try {
            hideCover(view);
            Mode mode = mode();''', marker="hideCover(view);\n            Mode mode = mode();")
edit(fit, '''                    && (width != containerWidth || height != containerHeight);
        }
        return false;''', '''                    && (width != containerWidth || height != containerHeight);
        }
        if (mode == Mode.SMART) {
            // A video much further from the window's shape than MAX_SMART would need more zoom
            // than looks right, so it is left at TikTok's size.
            return sameWay(width, height, containerWidth, containerHeight)
                    && closeInShape(width, height, containerWidth, containerHeight, MAX_SMART)
                    && (width != containerWidth || height != containerHeight);
        }
        return false;''', marker="mode == Mode.SMART) {\n            // A video much")
edit(fit, '''    static boolean closeInShape(int width, int height, int containerWidth, int containerHeight) {
        double video = width / (double) height;
        double space = containerWidth / (double) containerHeight;
        double apart = video > space ? video / space : space / video;
        return apart <= MAX_STRETCH + 1e-9;
    }''', '''    static boolean closeInShape(int width, int height, int containerWidth, int containerHeight) {
        return closeInShape(width, height, containerWidth, containerHeight, MAX_STRETCH);
    }

    /** How far smart stretch lets a video be from the window's shape. */
    static final double MAX_SMART = 1.45;

    /** The most smart stretch zooms a video: a tenth is already a visible slice off each side. */
    static final double MAX_SMART_ZOOM = 1.3;

    /**
     * How much wider than the window smart stretch makes the video. Covering a taller window than
     * the video's shape means making up a difference of {@code s}, the window's shape over the
     * video's. Zooming by the square root of it crops and stretches by the same amount, so
     * neither is as large as when one of them does all of it.
     */
    static double smartZoom(int width, int height, int containerWidth, int containerHeight) {
        double stretch = (containerHeight / (double) containerWidth) / (height / (double) width);
        return Math.min(MAX_SMART_ZOOM, Math.max(1.0, Math.sqrt(stretch)));
    }

    /** Whether the two shapes are within {@code limit} of each other, either way. */
    static boolean closeInShape(int width, int height, int containerWidth, int containerHeight,
                                double limit) {
        double video = width / (double) height;
        double space = containerWidth / (double) containerHeight;
        double apart = video > space ? video / space : space / video;
        return apart <= limit + 1e-9;
    }''', marker="static final double MAX_SMART = 1.45;")
edit(fit, "if (mode == Mode.STRETCH) return containerWidth;", '''if (mode == Mode.STRETCH) return containerWidth;
        if (mode == Mode.SMART) {
            return atLeastOne((int) Math.round(containerWidth * smartZoom(width, height, containerWidth, containerHeight)));
        }''', marker="return atLeastOne((int) Math.round(containerWidth * smartZoom(")
edit(fit, "if (mode == Mode.STRETCH) return containerHeight;", "if (mode == Mode.STRETCH || mode == Mode.SMART) return containerHeight;", marker="Mode.STRETCH || mode == Mode.SMART) return containerHeight;")
edit(fit, 'String label = mode == Mode.FIT ? "Fit" : mode == Mode.FILL ? "Fill" : "Stretch";',
     'String label = mode == Mode.FIT ? "Fit" : mode == Mode.FILL ? "Fill"\n                    : mode == Mode.SMART ? "Smart stretch" : "Stretch";', marker='"Smart stretch" : "Stretch"')
edit(fit, "            boolean stretch = Settings.STRETCH_VIDEO_TO_SCREEN.savedValue();",
     "            boolean stretch = Settings.STRETCH_VIDEO_TO_SCREEN.savedValue();\n            boolean smart = Settings.SMART_STRETCH_VIDEO_TO_SCREEN.savedValue();", marker="boolean smart = Settings.SMART")
edit(fit, '''            lines.add("Stretch the video to the screen: " + (stretch ? "on" : "off"));
            if ((fit || fill || stretch) && mode() == Mode.LEAVE_ALONE) {''', '''            lines.add("Stretch the video to the screen: " + (stretch ? "on" : "off"));
            lines.add("Smart stretch the video to the screen: " + (smart ? "on" : "off"));
            boolean cover = Settings.HIDE_VIDEO_COVER.savedValue();
            lines.add("Hide the cover picture between videos: " + (cover ? "on" : "off"));
            if (cover) {
                lines.add("Cover pictures hidden: " + CoverHider.HIDDEN.get()
                        + ". Last one hidden: " + CoverHider.lastHidden());
                lines.add("Around the last video: " + CoverHider.lastSeen());
            }
            if ((fit || fill || stretch || smart) && mode() == Mode.LEAVE_ALONE) {''', marker="Smart stretch the video to the screen: ")

# ---------------------------------------------------------------- the existing stretch tests
test = TEST + "interaction/VideoFitTest.java"
edit(test, '''        // A 3:4 video on a 20:9 phone is two thirds off, which would look plainly squashed.
        assertFalse(VideoFit.wants(VideoFit.Mode.STRETCH, 1080, 1440, 1080, 2400));
        // A third off exactly still stretches, and a pixel past it doesn't.
        assertTrue(VideoFit.wants(VideoFit.Mode.STRETCH, 1200, 1600, 900, 1600));
        assertFalse(VideoFit.wants(VideoFit.Mode.STRETCH, 1201, 1600, 900, 1600));''',
     '''        // A 3:4 video on a 20:9 phone is two thirds off, and now stretches too.
        assertTrue(VideoFit.wants(VideoFit.Mode.STRETCH, 1080, 1440, 1080, 2400));
        // One more than twice off in shape keeps TikTok's size.
        assertFalse(VideoFit.wants(VideoFit.Mode.STRETCH, 1080, 1100, 1080, 2400));
        // Twice off exactly still stretches, and a pixel past it doesn't.
        assertTrue(VideoFit.wants(VideoFit.Mode.STRETCH, 500, 1000, 500, 2000));
        assertFalse(VideoFit.wants(VideoFit.Mode.STRETCH, 501, 1000, 500, 2000));''', optional=True)

# ---------------------------------------------------------------- the lists the build reads
defaults = "patches/src/main/resources/settings-defaults.json"
edit(defaults, '''      "stretch_video_to_screen"
    ],''', '''      "stretch_video_to_screen",
      "smart_stretch_video_to_screen",
      "hide_video_cover"
    ],''', marker='"smart_stretch_video_to_screen",\n      "hide_video_cover"')
text = read(defaults)
if '"smart_stretch_video_to_screen": {' not in text:
    split = text.index('\n  "settings": {')
    head, body = text[:split], text[split:]
    keys = re.findall(r'\n    "([a-z0-9_]+)": \{\n      "field"', body)
    for key, field in (("smart_stretch_video_to_screen", "SMART_STRETCH_VIDEO_TO_SCREEN"),
                       ("hide_video_cover", "HIDE_VIDEO_COVER")):
        after = next((k for k in sorted(keys) if k > key), None)
        block = ('    "%s": {\n      "field": "%s",\n      "key": "%s",\n      "type": "boolean",\n      "default": false\n    },\n'
                 % (key, field, key))
        if after is None:
            failed.append(defaults + ": no key sorts after " + key)
            continue
        marker = '    "%s": {\n      "field"' % after
        if body.count(marker) != 1:
            failed.append(defaults + ": could not place " + key)
            continue
        body = body.replace(marker, block + marker)
        keys.append(key)
    write(defaults, head + body)
json.loads(read(defaults))

edit("patches/settings-defaults-owners.json", '''      "STRETCH_VIDEO_TO_SCREEN"
    ],''', '''      "STRETCH_VIDEO_TO_SCREEN",
      "SMART_STRETCH_VIDEO_TO_SCREEN",
      "HIDE_VIDEO_COVER"
    ],''', marker='"SMART_STRETCH_VIDEO_TO_SCREEN",\n      "HIDE_VIDEO_COVER"')
json.loads(read("patches/settings-defaults-owners.json"))

option = '''        {
          "key": "%s",
          "title": "Default: %s",
          "description": null,
          "required": false,
          "type": "kotlin.Boolean",
          "default": false,
          "values": null
        }'''
old_option = option % ("stretch_video_to_screen", "stretch video to screen")
edit("patches-list.json", old_option,
     old_option + ",\n" + option % ("smart_stretch_video_to_screen", "smart stretch video to screen")
     + ",\n" + option % ("hide_video_cover", "hide video cover"), marker='"key": "smart_stretch_video_to_screen"')
json.loads(read("patches-list.json"))


# ================================================================ Edge-warp stretch
# A third way to cover the window, kept apart from Smart stretch: the video is sized like Stretch
# and a shader on the video view spreads the stretching toward the top and bottom.
edit(EXT + "settings/Settings.java",
     '''    public static final BooleanSetting SMART_STRETCH_VIDEO_TO_SCREEN =
            new BooleanSetting("smart_stretch_video_to_screen", FALSE);
''',
     '''    public static final BooleanSetting SMART_STRETCH_VIDEO_TO_SCREEN =
            new BooleanSetting("smart_stretch_video_to_screen", FALSE);
    /**
     * Cover the window like stretch, but keep the middle of the video in its own shape and put the
     * stretching toward the top and bottom edges, with a thin crop off each side.
     */
    public static final BooleanSetting EDGE_WARP_VIDEO_TO_SCREEN =
            new BooleanSetting("edge_warp_video_to_screen", FALSE);
''', marker="EDGE_WARP_VIDEO_TO_SCREEN")

edit(page,
     '''            // One at a time: each sizes the video its own way, so turning one on turns the rest off.
            TogglePreference[] rows = {fit, fill, stretch, smart};
            BooleanSetting[] switches = {Settings.FIT_VIDEO_TO_SCREEN, Settings.FILL_VIDEO_TO_SCREEN,
                    Settings.STRETCH_VIDEO_TO_SCREEN, Settings.SMART_STRETCH_VIDEO_TO_SCREEN};''',
     '''            TogglePreference warp = new TogglePreference(context, "Edge-warp stretch the video to the screen",
                    "Cover the whole window and keep the middle of the picture in its normal "
                            + "shape, spreading the stretching toward the top and bottom edges, "
                            + "where the caption and buttons sit. A thin slice is cropped off each "
                            + "side. Needs Android 13 or newer; on an older phone it acts like "
                            + "Stretch. It redraws the video through a graphics effect, so turn it "
                            + "off if you see streaks or stutter.",
                    Settings.EDGE_WARP_VIDEO_TO_SCREEN);
            // One at a time: each sizes the video its own way, so turning one on turns the rest off.
            TogglePreference[] rows = {fit, fill, stretch, smart, warp};
            BooleanSetting[] switches = {Settings.FIT_VIDEO_TO_SCREEN, Settings.FILL_VIDEO_TO_SCREEN,
                    Settings.STRETCH_VIDEO_TO_SCREEN, Settings.SMART_STRETCH_VIDEO_TO_SCREEN,
                    Settings.EDGE_WARP_VIDEO_TO_SCREEN};''',
     marker="Settings.EDGE_WARP_VIDEO_TO_SCREEN};")
edit(page, "            addPreference(smart);\n", "            addPreference(smart);\n            addPreference(warp);\n", marker="addPreference(warp);")

edit(fit, "enum Mode { LEAVE_ALONE, FIT, FILL, STRETCH, SMART }", "enum Mode { LEAVE_ALONE, FIT, FILL, STRETCH, SMART, WARP }", marker="SMART, WARP }")
edit(fit, "        if (Settings.SMART_STRETCH_VIDEO_TO_SCREEN.get()) return Mode.SMART;\n",
     "        if (Settings.SMART_STRETCH_VIDEO_TO_SCREEN.get()) return Mode.SMART;\n        if (Settings.EDGE_WARP_VIDEO_TO_SCREEN.get()) return Mode.WARP;\n", marker="return Mode.WARP;")
edit(fit, "return mode == Mode.FILL || mode == Mode.STRETCH || mode == Mode.SMART;",
     "return mode == Mode.FILL || mode == Mode.STRETCH || mode == Mode.SMART || mode == Mode.WARP;", marker="mode == Mode.SMART || mode == Mode.WARP;")
edit(fit, "        else CoverHider.clear(view);\n    }\n", '''        else CoverHider.clear(view);
    }

    /**
     * Edge-warp stretch sizes the video exactly as Stretch does and then spreads the stretch
     * toward the top and bottom with a shader on the video view. Every other mode takes the
     * shader off a view that an earlier video, or an earlier choice of switch, had put it on.
     */
    private static void edgeWarp(Mode mode, View view, int videoWidth, int videoHeight,
                                 int width, int height) {
        if (mode == Mode.WARP) EdgeWarp.apply(view, videoWidth, videoHeight, width, height);
        else EdgeWarp.clear(view);
    }
''', marker="private static void edgeWarp(")
edit(fit, '''            if (centred) watch(view, videoWidth, videoHeight, width, height);
            return copy;''', '''            if (centred) watch(view, videoWidth, videoHeight, width, height);
            edgeWarp(mode, view, videoWidth, videoHeight, width, height);
            return copy;''', marker="edgeWarp(mode, view, videoWidth, videoHeight, width, height);\n            return copy;")
edit(fit, '''            if (centred) watch(view, videoWidth, videoHeight, width, height);
            return width;''', '''            if (centred) watch(view, videoWidth, videoHeight, width, height);
            edgeWarp(mode, view, videoWidth, videoHeight, width, height);
            return width;''', marker="edgeWarp(mode, view, videoWidth, videoHeight, width, height);\n            return width;")
edit(fit, '''        unwatch(view);
        uncentre(view);
        return result;''', '''        unwatch(view);
        uncentre(view);
        EdgeWarp.clear(view);
        return result;''', marker="EdgeWarp.clear(view);\n        return result;")
edit(fit, '''        unwatch(view);
        uncentre(view);
        return LEAVE;''', '''        unwatch(view);
        uncentre(view);
        EdgeWarp.clear(view);
        return LEAVE;''', marker="EdgeWarp.clear(view);\n        return LEAVE;")
edit(fit, '''            watch.height = height;
            note("after the space changed"''', '''            watch.height = height;
            if (change) edgeWarp(mode, view, watch.videoWidth, watch.videoHeight, width, height);
            else EdgeWarp.clear(view);
            note("after the space changed"''', marker="if (change) edgeWarp(")
edit(fit, '''                    && closeInShape(width, height, containerWidth, containerHeight, MAX_SMART)
                    && (width != containerWidth || height != containerHeight);
        }
        return false;''', '''                    && closeInShape(width, height, containerWidth, containerHeight, MAX_SMART)
                    && (width != containerWidth || height != containerHeight);
        }
        if (mode == Mode.WARP) {
            // The warp keeps the middle natural only up to a point, so a video further from the
            // window's shape than MAX_SMART is left at TikTok's size rather than pulled out of it.
            return sameWay(width, height, containerWidth, containerHeight)
                    && closeInShape(width, height, containerWidth, containerHeight, MAX_SMART)
                    && (width != containerWidth || height != containerHeight);
        }
        return false;''', marker="mode == Mode.WARP) {\n            // The warp")
edit(fit, "        if (mode == Mode.STRETCH) return containerWidth;\n        if (mode == Mode.SMART) {",
     "        if (mode == Mode.STRETCH || mode == Mode.WARP) return containerWidth;\n        if (mode == Mode.SMART) {", marker="Mode.STRETCH || mode == Mode.WARP) return containerWidth;")
edit(fit, "if (mode == Mode.STRETCH || mode == Mode.SMART) return containerHeight;",
     "if (mode == Mode.STRETCH || mode == Mode.SMART || mode == Mode.WARP) return containerHeight;", marker="Mode.SMART || mode == Mode.WARP) return containerHeight;")
edit(fit, ': mode == Mode.SMART ? "Smart stretch" : "Stretch";',
     ': mode == Mode.SMART ? "Smart stretch" : mode == Mode.WARP ? "Edge-warp stretch" : "Stretch";', marker='"Edge-warp stretch" : "Stretch"')
edit(fit, "            boolean smart = Settings.SMART_STRETCH_VIDEO_TO_SCREEN.savedValue();",
     "            boolean smart = Settings.SMART_STRETCH_VIDEO_TO_SCREEN.savedValue();\n            boolean warp = Settings.EDGE_WARP_VIDEO_TO_SCREEN.savedValue();", marker="boolean warp = Settings.EDGE_WARP")
edit(fit, '''            lines.add("Smart stretch the video to the screen: " + (smart ? "on" : "off"));''',
     '''            lines.add("Smart stretch the video to the screen: " + (smart ? "on" : "off"));
            lines.add("Edge-warp stretch the video to the screen: " + (warp ? "on" : "off"));
            if (warp) {
                lines.add("Edge warp supported on this phone (Android 13+): "
                        + (EdgeWarp.supported() ? "yes" : "no, videos get plain stretch"));
                lines.add("Edge warp changed " + EdgeWarp.APPLIED.get() + " times; "
                        + EdgeWarp.SURFACE.get() + " views were drawn through a SurfaceView, which it cannot reach");
            }''', marker="Edge-warp stretch the video to the screen: ")
edit(fit, "if ((fit || fill || stretch || smart) && mode() == Mode.LEAVE_ALONE) {",
     "if ((fit || fill || stretch || smart || warp) && mode() == Mode.LEAVE_ALONE) {", marker="stretch || smart || warp) && mode()")

edit(defaults, '''      "smart_stretch_video_to_screen",
      "hide_video_cover"''', '''      "smart_stretch_video_to_screen",
      "edge_warp_video_to_screen",
      "hide_video_cover"''', marker='"edge_warp_video_to_screen",\n      "hide_video_cover"')
text = read(defaults)
if '"edge_warp_video_to_screen": {' not in text:
    split = text.index('\n  "settings": {')
    head, body = text[:split], text[split:]
    keys = re.findall(r'\n    "([a-z0-9_]+)": \{\n      "field"', body)
    after = next((k for k in sorted(keys) if k > "edge_warp_video_to_screen"), None)
    marker = '    "%s": {\n      "field"' % after
    if after is None or body.count(marker) != 1:
        failed.append(defaults + ": could not place edge_warp_video_to_screen")
    else:
        block = '    "edge_warp_video_to_screen": {\n      "field": "EDGE_WARP_VIDEO_TO_SCREEN",\n      "key": "edge_warp_video_to_screen",\n      "type": "boolean",\n      "default": false\n    },\n'
        write(defaults, head + body.replace(marker, block + marker))
json.loads(read(defaults))
edit("patches/settings-defaults-owners.json", '''      "SMART_STRETCH_VIDEO_TO_SCREEN",
      "HIDE_VIDEO_COVER"''', '''      "SMART_STRETCH_VIDEO_TO_SCREEN",
      "EDGE_WARP_VIDEO_TO_SCREEN",
      "HIDE_VIDEO_COVER"''', marker='"EDGE_WARP_VIDEO_TO_SCREEN",\n      "HIDE_VIDEO_COVER"')
json.loads(read("patches/settings-defaults-owners.json"))
smart_option = option % ("smart_stretch_video_to_screen", "smart stretch video to screen")
edit("patches-list.json", smart_option, smart_option + ",\n" + option % ("edge_warp_video_to_screen", "edge warp video to screen"), marker='"key": "edge_warp_video_to_screen"')
json.loads(read("patches-list.json"))

if failed:
    print("Smart stretch could not be applied:")
    for line in failed:
        print("  " + line)
    sys.exit(1)
print("Smart stretch applied.")
