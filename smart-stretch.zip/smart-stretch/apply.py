#!/usr/bin/env python3
"""Adds Edge-warp stretch, Hide cover and Optimize TikTok to a HushFeed checkout, in place.

Run from the repository root. Each edit is anchored on text that is in the file today. A file
that has changed so much that an anchor is gone stops the script with a message naming it,
instead of building a half-edited bundle. Running it twice is harmless.
"""
import json
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
EXT = "extensions/tiktok/src/main/java/app/morphe/extension/tiktok/"
TEST = "extensions/tiktok/src/test/java/app/morphe/extension/tiktok/"
failed = []


def read(path):
    with open(path, encoding="utf-8") as handle:
        return handle.read()


def write(path, text):
    with open(path, "w", encoding="utf-8", newline="") as handle:
        handle.write(text)


def edit(path, old, new, marker=None, optional=False):
    text = read(path)
    if marker is not None and marker in text:
        return
    if text.count(old) != 1:
        if not optional:
            failed.append("%s: expected one match for: %s (found %d)"
                          % (path, old[:80].replace("\n", "\\n"), text.count(old)))
        return
    write(path, text.replace(old, new))


fit = EXT + "interaction/VideoFit.java"
page = EXT + "settings/preference/categories/PlaybackPreferenceCategory.java"
defaults = "patches/src/main/resources/settings-defaults.json"
owners = "patches/settings-defaults-owners.json"

if "EdgeWarp.apply(" in read(fit) and os.path.exists(EXT + "interaction/EdgeWarp.java"):
    print("Edge-warp stretch already applied.")
    sys.exit(0)

# ---------------------------------------------------------------- new files
for name in ("CoverHider.java", "EdgeWarp.java"):
    shutil.copyfile(os.path.join(HERE, "files", "main", "interaction", name), EXT + "interaction/" + name)
shutil.copyfile(os.path.join(HERE, "files", "test", "interaction", "EdgeWarpTest.java"),
                TEST + "interaction/EdgeWarpTest.java")
# Classes an earlier version of this script added, which are gone now.
for stale in (EXT + "interaction/SmartStretch.java", EXT + "interaction/FlashRecorder.java",
              TEST + "interaction/SmartStretchTest.java", TEST + "interaction/SmartZoomTest.java"):
    if os.path.exists(stale):
        os.remove(stale)

# ---------------------------------------------------------------- Settings.java
settings = EXT + "settings/Settings.java"
edit(settings,
     '''    public static final BooleanSetting BLEND_VIDEO_TO_SCREEN =
            new BooleanSetting("blend_video_to_screen", FALSE);
''',
     '''    public static final BooleanSetting BLEND_VIDEO_TO_SCREEN =
            new BooleanSetting("blend_video_to_screen", FALSE);
    /**
     * Cover the window like stretch, but keep the middle of the video in its own shape and put the
     * stretching toward the top and bottom edges, with a thin crop off each side.
     */
    public static final BooleanSetting EDGE_WARP_VIDEO_TO_SCREEN =
            new BooleanSetting("edge_warp_video_to_screen", FALSE);
    /** Don't draw the still cover picture TikTok shows for a moment before each video starts. */
    public static final BooleanSetting HIDE_VIDEO_COVER =
            new BooleanSetting("hide_video_cover", FALSE);
''', marker="EDGE_WARP_VIDEO_TO_SCREEN")
edit(settings,
     '''    public static final BooleanSetting DROP_ANIMATED_IMAGE_CACHE =
            new BooleanSetting("drop_animated_image_cache", FALSE);
''',
     '''    public static final BooleanSetting DROP_ANIMATED_IMAGE_CACHE =
            new BooleanSetting("drop_animated_image_cache", FALSE);
    /** One switch for the start-up and drawing chores in Performance. Touches no privacy switch. */
    public static final BooleanSetting OPTIMIZE_TIKTOK =
            new BooleanSetting("optimize_tiktok", FALSE, true);
''', marker="OPTIMIZE_TIKTOK")

# ---------------------------------------------------------------- the Playback page
edit(page,
     '''            // One at a time: each sizes the video its own way, so turning one on turns the rest off.
            TogglePreference[] rows = {fit, fill, stretch, blend};
            BooleanSetting[] switches = {Settings.FIT_VIDEO_TO_SCREEN, Settings.FILL_VIDEO_TO_SCREEN,
                    Settings.STRETCH_VIDEO_TO_SCREEN, Settings.BLEND_VIDEO_TO_SCREEN};''',
     '''            TogglePreference warp = new TogglePreference(context, "Edge-warp stretch the video to the screen",
                    "Cover the whole window and keep the middle of the picture in its normal "
                            + "shape, spreading the stretching toward the top and bottom edges, "
                            + "where the caption and buttons sit. A thin slice is cropped off each "
                            + "side. Needs Android 13 or newer; on an older phone it acts like "
                            + "Stretch. It redraws the video through a graphics effect, so turn it "
                            + "off if you see streaks or stutter.",
                    Settings.EDGE_WARP_VIDEO_TO_SCREEN);
            // One at a time: each sizes the video its own way, so turning one on turns the rest off.
            TogglePreference[] rows = {fit, fill, stretch, blend, warp};
            BooleanSetting[] switches = {Settings.FIT_VIDEO_TO_SCREEN, Settings.FILL_VIDEO_TO_SCREEN,
                    Settings.STRETCH_VIDEO_TO_SCREEN, Settings.BLEND_VIDEO_TO_SCREEN,
                    Settings.EDGE_WARP_VIDEO_TO_SCREEN};''', marker="Settings.EDGE_WARP_VIDEO_TO_SCREEN};")
edit(page,
     '''            addPreference(blend);
        }''',
     '''            addPreference(blend);
            addPreference(warp);
            addPreference(new TogglePreference(context, "Hide the cover picture between videos",
                    "Don't show the still picture TikTok puts up for a moment before each video "
                            + "starts, so the video is the only thing you see as you scroll. The "
                            + "screen can stay dark for a split second until the first frame. "
                            + "Needs Android 13 or newer. Photo posts are left alone.",
                    Settings.HIDE_VIDEO_COVER));
        }''', marker="Settings.HIDE_VIDEO_COVER));")

# ---------------------------------------------------------------- VideoFit.java
edit(fit, "enum Mode { LEAVE_ALONE, FIT, FILL, STRETCH, BLEND }", "enum Mode { LEAVE_ALONE, FIT, FILL, STRETCH, BLEND, WARP }", marker="BLEND, WARP }")
edit(fit, "        if (Settings.BLEND_VIDEO_TO_SCREEN.get()) return Mode.BLEND;\n",
     "        if (Settings.BLEND_VIDEO_TO_SCREEN.get()) return Mode.BLEND;\n        if (Settings.EDGE_WARP_VIDEO_TO_SCREEN.get()) return Mode.WARP;\n", marker="return Mode.WARP;")
edit(fit, "return mode == Mode.FILL || mode == Mode.STRETCH || mode == Mode.BLEND;",
     "return mode == Mode.FILL || mode == Mode.STRETCH || mode == Mode.BLEND || mode == Mode.WARP;", marker="Mode.BLEND || mode == Mode.WARP;\n    }")
edit(fit, "        return mode == Mode.STRETCH || mode == Mode.BLEND;\n    }",
     "        return mode == Mode.STRETCH || mode == Mode.BLEND || mode == Mode.WARP;\n    }", marker="Mode.BLEND || mode == Mode.WARP;\n    }\n\n")
edit(fit, '''    /** TikTok's own result for the feed cell, on a view with its own gravity. */''',
     '''    /** The cover picture is hidden or given back whatever the fit switches say. */
    private static void hideCover(View view) {
        if (Settings.HIDE_VIDEO_COVER.get()) CoverHider.apply(view);
        else CoverHider.clear(view);
    }

    /**
     * Edge-warp stretch sizes the video exactly as Stretch does and then spreads the stretch
     * toward the top and bottom with a shader on the video view. Every other mode takes the
     * shader off a view that an earlier video, or an earlier choice of switch, had put it on.
     */
    private static void edgeWarp(Mode mode, View view, int videoWidth, int videoHeight,
                                 int width, int height) {
        if (mode == Mode.WARP) EdgeWarp.apply(view, videoWidth, videoHeight, width, height);
        else EdgeWarp.clear(view);
    }

    /** TikTok's own result for the feed cell, on a view with its own gravity. */''', marker="private static void edgeWarp(")
edit(fit, '''        if (view == null || result == null) return result;
        try {
            // The switches before the reads''', '''        if (view == null || result == null) return result;
        try {
            hideCover(view);
            // The switches before the reads''', marker="hideCover(view);\n            // The switches")
edit(fit, '''        if (view == null || result == null) return LEAVE;
        try {
            Mode mode = mode();''', '''        if (view == null || result == null) return LEAVE;
        try {
            hideCover(view);
            Mode mode = mode();''', marker="hideCover(view);\n            Mode mode = mode();")
edit(fit, '''            shapeCover(view, reshapes(mode));
            return copy;''', '''            shapeCover(view, reshapes(mode));
            edgeWarp(mode, view, videoWidth, videoHeight, width, height);
            return copy;''', marker="edgeWarp(mode, view, videoWidth, videoHeight, width, height);\n            return copy;")
edit(fit, '''            shapeCover(view, reshapes(mode));
            return width;''', '''            shapeCover(view, reshapes(mode));
            edgeWarp(mode, view, videoWidth, videoHeight, width, height);
            return width;''', marker="edgeWarp(mode, view, videoWidth, videoHeight, width, height);\n            return width;")
edit(fit, '''        shapeCover(view, false);
        return result;''', '''        shapeCover(view, false);
        EdgeWarp.clear(view);
        return result;''', marker="EdgeWarp.clear(view);\n        return result;")
edit(fit, '''        shapeCover(view, false);
        return LEAVE;''', '''        shapeCover(view, false);
        EdgeWarp.clear(view);
        return LEAVE;''', marker="EdgeWarp.clear(view);\n        return LEAVE;")
edit(fit, '''            watch.height = height;
            note("after the space changed"''', '''            watch.height = height;
            if (change) edgeWarp(mode, view, watch.videoWidth, watch.videoHeight, width, height);
            else EdgeWarp.clear(view);
            note("after the space changed"''', marker="if (change) edgeWarp(")
edit(fit, '''                    || blendHeight(width, height, containerWidth, containerHeight) != height);
        }
        return false;''', '''                    || blendHeight(width, height, containerWidth, containerHeight) != height);
        }
        if (mode == Mode.WARP) {
            // The warp keeps the middle natural only up to a point, so a video further from the
            // window's shape than that is left at TikTok's size rather than pulled out of it.
            return sameWay(width, height, containerWidth, containerHeight)
                    && closeInShape(width, height, containerWidth, containerHeight, EdgeWarp.MAX_SHAPE)
                    && (width != containerWidth || height != containerHeight);
        }
        return false;''', marker="mode == Mode.WARP) {\n            // The warp")
edit(fit, "        if (mode == Mode.STRETCH) return containerWidth;",
     "        if (mode == Mode.STRETCH || mode == Mode.WARP) return containerWidth;", marker="Mode.STRETCH || mode == Mode.WARP) return containerWidth;")
edit(fit, "        if (mode == Mode.STRETCH) return containerHeight;",
     "        if (mode == Mode.STRETCH || mode == Mode.WARP) return containerHeight;", marker="Mode.STRETCH || mode == Mode.WARP) return containerHeight;")
edit(fit, ': mode == Mode.BLEND ? "Crop and stretch" : "Stretch";',
     ': mode == Mode.BLEND ? "Crop and stretch" : mode == Mode.WARP ? "Edge-warp stretch" : "Stretch";',
     marker='"Edge-warp stretch" : "Stretch"')
edit(fit, "            boolean blend = Settings.BLEND_VIDEO_TO_SCREEN.savedValue();",
     "            boolean blend = Settings.BLEND_VIDEO_TO_SCREEN.savedValue();\n            boolean warp = Settings.EDGE_WARP_VIDEO_TO_SCREEN.savedValue();", marker="boolean warp = Settings.EDGE_WARP")
edit(fit, '''            lines.add("Crop and stretch to fill the screen: " + (blend ? "on" : "off"));
            if ((fit || fill || stretch || blend) && mode() == Mode.LEAVE_ALONE) {''',
     '''            lines.add("Crop and stretch to fill the screen: " + (blend ? "on" : "off"));
            lines.add("Edge-warp stretch the video to the screen: " + (warp ? "on" : "off"));
            if (warp) {
                lines.add("Edge warp supported on this phone (Android 13+): "
                        + (EdgeWarp.supported() ? "yes" : "no, videos get plain stretch"));
                lines.add("Edge warp changed " + EdgeWarp.APPLIED.get() + " times; "
                        + EdgeWarp.SURFACE.get() + " views were drawn through a SurfaceView, which it cannot reach");
            }
            boolean cover = Settings.HIDE_VIDEO_COVER.savedValue();
            lines.add("Hide the cover picture between videos: " + (cover ? "on" : "off"));
            if (cover) {
                lines.add("Cover pictures hidden: " + CoverHider.HIDDEN.get()
                        + ". Last one hidden: " + CoverHider.lastHidden());
                lines.add("Around the last video: " + CoverHider.lastSeen());
            }
            if ((fit || fill || stretch || blend || warp) && mode() == Mode.LEAVE_ALONE) {''',
     marker="Edge-warp stretch the video to the screen: ")

# ---------------------------------------------------------------- Optimize TikTok
edit(EXT + "settings/preference/categories/ExtensionPreferenceCategory.java",
     '''        if (hasPerformance()) {
            addPreference(new SectionHeadingPreference(context, "Performance"));
        }''',
     '''        if (hasPerformance()) {
            addPreference(new SectionHeadingPreference(context, "Performance"));
            // The chores that cost time while TikTok starts or draws. No privacy switch is in
            // this list, and loading upcoming videos ahead of time is left as it is, because
            // stopping it makes videos start slower.
            final app.morphe.extension.shared.settings.BooleanSetting[] preset = {
                    Settings.SKIP_SPLASH_AD, Settings.SKIP_UPDATE_CHECKS,
                    Settings.DROP_ANIMATED_IMAGE_CACHE, Settings.UNCAP_REFRESH_RATE};
            TogglePreference optimize = new TogglePreference(
                    context,
                    "Optimize TikTok",
                    "One switch for the start-up and drawing chores: skip the splash ad and the "
                            + "update checks while TikTok starts, don't decode animated frames "
                            + "ahead, and keep the screen's refresh rate. It changes none of the "
                            + "Privacy switches, and it leaves loading videos ahead of time alone. "
                            + "Turning it off turns these four off again.",
                    Settings.OPTIMIZE_TIKTOK);
            optimize.setOnPreferenceChangeListener((preference, value) -> {
                boolean on = Boolean.TRUE.equals(value);
                for (app.morphe.extension.shared.settings.BooleanSetting setting : preset) {
                    setting.save(on);
                    android.preference.Preference row = findPreference(setting.key);
                    if (row instanceof android.preference.TwoStatePreference) {
                        ((android.preference.TwoStatePreference) row).setChecked(on);
                    }
                }
                return true;
            });
            addPreference(optimize);
        }''', marker="Settings.OPTIMIZE_TIKTOK);")

# ---------------------------------------------------------------- the lists the build reads
def place(key, field):
    text = read(defaults)
    if '"%s": {' % key in text:
        return
    split = text.index('\n  "settings": {')
    head, body = text[:split], text[split:]
    keys = re.findall(r'\n    "([a-z0-9_]+)": \{\n      "field"', body)
    after = next((k for k in sorted(keys) if k > key), None)
    marker = '    "%s": {\n      "field"' % after
    if after is None or body.count(marker) != 1:
        failed.append(defaults + ": could not place " + key)
        return
    block = ('    "%s": {\n      "field": "%s",\n      "key": "%s",\n      "type": "boolean",\n      "default": false\n    },\n'
             % (key, field, key))
    write(defaults, head + body.replace(marker, block + marker))


edit(defaults, '''      "stretch_video_to_screen",
      "blend_video_to_screen"
    ],''', '''      "stretch_video_to_screen",
      "blend_video_to_screen",
      "edge_warp_video_to_screen",
      "hide_video_cover"
    ],''', marker='"edge_warp_video_to_screen",\n      "hide_video_cover"')
edit(defaults, '''    "Skip the splash ad": [
      "skip_splash_ad"
    ],''', '''    "Skip the splash ad": [
      "skip_splash_ad",
      "optimize_tiktok"
    ],''', marker='"skip_splash_ad",\n      "optimize_tiktok"')
for key, field in (("edge_warp_video_to_screen", "EDGE_WARP_VIDEO_TO_SCREEN"),
                   ("hide_video_cover", "HIDE_VIDEO_COVER"),
                   ("optimize_tiktok", "OPTIMIZE_TIKTOK")):
    place(key, field)
json.loads(read(defaults))

edit(owners, '''      "STRETCH_VIDEO_TO_SCREEN",
      "BLEND_VIDEO_TO_SCREEN"
    ],''', '''      "STRETCH_VIDEO_TO_SCREEN",
      "BLEND_VIDEO_TO_SCREEN",
      "EDGE_WARP_VIDEO_TO_SCREEN",
      "HIDE_VIDEO_COVER"
    ],''', marker='"EDGE_WARP_VIDEO_TO_SCREEN",\n      "HIDE_VIDEO_COVER"')
edit(owners, '''    "Skip the splash ad": [
      "SKIP_SPLASH_AD"
    ],''', '''    "Skip the splash ad": [
      "SKIP_SPLASH_AD",
      "OPTIMIZE_TIKTOK"
    ],''', marker='"SKIP_SPLASH_AD",\n      "OPTIMIZE_TIKTOK"')
json.loads(read(owners))

# The options list is generated metadata; add to it when its shape is what this expects.
option = '''        {
          "key": "%s",
          "title": "Default: %s",
          "description": null,
          "required": false,
          "type": "kotlin.Boolean",
          "default": false,
          "values": null
        }'''
listing = "patches-list.json"
for anchor, adds in (
        (("stretch_video_to_screen", "stretch video to screen"),
         [("edge_warp_video_to_screen", "edge warp video to screen"), ("hide_video_cover", "hide video cover")]),
        (("skip_splash_ad", "skip splash ad"), [("optimize_tiktok", "optimize tiktok")])):
    if '"key": "%s"' % adds[0][0] in read(listing):
        continue
    old = option % anchor
    edit(listing, old, old + "".join(",\n" + option % add for add in adds), optional=True)
json.loads(read(listing))

if failed:
    print("Edge-warp stretch could not be applied:")
    for line in failed:
        print("  " + line)
    sys.exit(1)
print("Edge-warp stretch applied.")
