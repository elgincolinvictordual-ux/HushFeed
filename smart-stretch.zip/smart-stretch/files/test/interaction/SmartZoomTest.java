package app.morphe.extension.tiktok.interaction;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/** Smart stretch: a thin crop off each side and a little stretch, half and half. */
public class SmartZoomTest {

    @Test
    public void a_nine_sixteen_video_on_a_tall_phone_is_zoomed_a_little() {
        // 720x1280 in a 720x1608 window: the window is about a quarter taller.
        double zoom = VideoFit.smartZoom(720, 1280, 720, 1608);
        assertEquals(Math.sqrt(1608 / 720.0 / (1280 / 720.0)), zoom, 1e-9);
        assertTrue(zoom > 1.1 && zoom < 1.14);
    }

    @Test
    public void the_zoom_is_never_less_than_none_or_more_than_its_cap() {
        // A video already as tall as the window's shape is not zoomed at all.
        assertEquals(1.0, VideoFit.smartZoom(720, 1608, 720, 1608), 1e-9);
        // A video wider than the window's shape would need a negative zoom: stays at none.
        assertEquals(1.0, VideoFit.smartZoom(720, 1608, 720, 1000), 1e-9);
        assertTrue(VideoFit.smartZoom(720, 720, 720, 1608) <= VideoFit.MAX_SMART_ZOOM + 1e-9);
    }

    @Test
    public void smart_stretch_covers_the_window_height_and_runs_wider_than_the_window() {
        int width = VideoFit.widthFor(VideoFit.Mode.SMART, 720, 1280, 720, 1608);
        int height = VideoFit.heightFor(VideoFit.Mode.SMART, 720, 1280, 720, 1608);
        assertEquals(1608, height);
        assertTrue(width > 720 && width < 720 * 1.2);
    }

    @Test
    public void smart_stretch_takes_what_stretch_takes_inside_its_own_limit() {
        assertTrue(VideoFit.wants(VideoFit.Mode.SMART, 1080, 1920, 1080, 2400));
        assertTrue(VideoFit.wants(VideoFit.Mode.STRETCH, 1080, 1440, 1080, 2400));
        assertFalse(VideoFit.wants(VideoFit.Mode.SMART, 1080, 1440, 1080, 2400));
        assertFalse(VideoFit.wants(VideoFit.Mode.SMART, 1080, 2400, 1080, 2400));
        assertFalse(VideoFit.wants(VideoFit.Mode.SMART, 1920, 1080, 1080, 2400));
    }
}
