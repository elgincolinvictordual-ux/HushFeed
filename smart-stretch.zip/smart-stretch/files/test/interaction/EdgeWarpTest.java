package app.morphe.extension.tiktok.interaction;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/** The numbers behind Edge-warp stretch: where each row of the window is drawn from. */
public class EdgeWarpTest {

    @Test
    public void a_video_already_the_windows_shape_has_nothing_to_spread() {
        assertNull(EdgeWarp.curve(720, 1608, 720, 1608));
    }

    @Test
    public void the_curve_covers_the_window_exactly_and_only_moves_forward() {
        double[] curve = EdgeWarp.curve(720, 1280, 720, 1608);
        assertNotNull(curve);
        assertEquals(0.0, EdgeWarp.warp(0.0, curve[0], curve[1]), 1e-9);
        assertEquals(0.5, EdgeWarp.warp(0.5, curve[0], curve[1]), 1e-9);
        assertEquals(1.0, EdgeWarp.warp(1.0, curve[0], curve[1]), 1e-9);
        double before = -1;
        for (int step = 0; step <= 100; step++) {
            double at = EdgeWarp.warp(step / 100.0, curve[0], curve[1]);
            assertTrue("went backwards at " + step, at > before);
            before = at;
        }
    }

    @Test
    public void the_middle_keeps_its_shape_and_the_edges_take_the_stretch() {
        double[] curve = EdgeWarp.curve(720, 1280, 720, 1608);
        assertNotNull(curve);
        double stretch = EdgeWarp.stretchOf(720, 1280, 720, 1608);
        double middle = stretch / (curve[2] * slope(curve, 0.5));
        double edge = stretch / (curve[2] * slope(curve, 0.0));
        assertEquals(1.0, middle, 1e-6);
        assertTrue(edge > 1.5);
        assertTrue(curve[2] >= EdgeWarp.MIN_ZOOM && curve[2] < 1.12);
    }

    @Test
    public void edge_warp_takes_what_smart_stretch_takes() {
        assertTrue(VideoFit.wants(VideoFit.Mode.WARP, 1080, 1920, 1080, 2400));
        assertFalse(VideoFit.wants(VideoFit.Mode.WARP, 1080, 1440, 1080, 2400));
        assertFalse(VideoFit.wants(VideoFit.Mode.WARP, 1920, 1080, 1080, 2400));
        assertEquals(VideoFit.widthFor(VideoFit.Mode.STRETCH, 1080, 1920, 1080, 2400),
                VideoFit.widthFor(VideoFit.Mode.WARP, 1080, 1920, 1080, 2400));
        assertEquals(VideoFit.heightFor(VideoFit.Mode.STRETCH, 1080, 1920, 1080, 2400),
                VideoFit.heightFor(VideoFit.Mode.WARP, 1080, 1920, 1080, 2400));
    }

    private static double slope(double[] curve, double t) {
        double h = 1e-5;
        double low = Math.max(0.0, t - h);
        double high = Math.min(1.0, t + h);
        return (EdgeWarp.warp(high, curve[0], curve[1]) - EdgeWarp.warp(low, curve[0], curve[1])) / (high - low);
    }
}
