/*
 * Copyright 2026 Hushfeed contributors
 * https://github.com/SysAdminDoc/hushfeed
 *
 * Built on icysymmetra/tiktok-patches-for-morphe (GPL-3.0).
 */
package app.morphe.extension.tiktok.interaction;

import android.annotation.TargetApi;
import android.graphics.RenderEffect;
import android.graphics.RuntimeShader;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicLong;

import app.morphe.extension.shared.Logger;

/**
 * Stops the still picture TikTok puts up for a moment before each video starts from being drawn,
 * so the video is the only thing on screen as you scroll.
 *
 * <p>The picture is a large image view somewhere in the video's page, not necessarily beside the
 * video itself: on the phones this was checked on, the video view sits alone in its parent and
 * the cover is elsewhere in the page. So the whole page is searched for image views that are
 * about as big as the page. They are not removed or hidden, because TikTok shows, fades and
 * hides the cover on its own schedule and would undo anything written to its visibility or
 * alpha. They are given a view effect that draws nothing instead, which TikTok never touches,
 * and everything TikTok does with the view carries on as before.
 *
 * <p>Only a page with a video surface in it is looked at, so a photo post, whose pictures are
 * the post, is left alone. Needs Android 13 (API 33), like {@link SmartStretch}; on an older
 * phone nothing here changes.
 */
final class CoverHider {
    private CoverHider() {}

    private static final String SHADER =
            "uniform shader content;\n"
                    + "half4 main(float2 p) {\n"
                    + "    return content.eval(p) * 0.0;\n"
                    + "}\n";

    /** The pictures made invisible beside one video view, found again at each layout pass. */
    private static final class Held implements View.OnLayoutChangeListener {
        final List<WeakReference<View>> hidden = new ArrayList<>();
        /** The page being watched while it is on screen, and the watcher put on it. */
        WeakReference<View> page;
        ViewTreeObserver.OnPreDrawListener watcher;
        long lastLook;

        @Override
        public void onLayoutChange(View video, int left, int top, int right, int bottom,
                                   int oldLeft, int oldTop, int oldRight, int oldBottom) {
            try {
                rescan(video, this);
            } catch (Throwable failure) {
                Logger.printException(() -> "Could not hide the cover picture", failure);
            }
        }
    }

    private static final Map<View, Held> HELD = Collections.synchronizedMap(new WeakHashMap<>());

    /** Pictures made invisible so far, and what sat around the last video, for the report. */
    static final AtomicLong HIDDEN = new AtomicLong();
    private static volatile String lastSeen = "";

    static String lastSeen() {
        return lastSeen;
    }

    private static volatile String lastHidden = "";

    /** The cover hidden most recently and what it sits in, for the report. */
    static String lastHidden() {
        return lastHidden;
    }

    /** How often the page is looked at again while it is on screen. */
    private static final long LOOK_EVERY_MS = 80;

    /** Looks for the cover beside this video view and hides it. Never throws. */
    static void apply(View video) {
        if (video == null) return;
        try {
            if (!SmartStretch.supported()) return;
            Held held = HELD.get(video);
            if (held == null) {
                held = new Held();
                video.addOnLayoutChangeListener(held);
                HELD.put(video, held);
            }
            rescan(video, held);
            watch(video, held);
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not hide the cover picture", failure);
        }
    }

    /**
     * Looks at the page again just before it is drawn, a few times a second. A cover can come
     * into the page after the video was set up: TikTok inflates parts of the page on demand, and
     * a video that is scrolled back to is put together again. Without this the cover that comes
     * late is the one that shows.
     */
    private static void watch(View video, Held held) {
        View page = pageOf(video);
        View current = held.page == null ? null : held.page.get();
        if (current == page && held.watcher != null) return;
        stopWatching(held);
        WeakReference<View> target = new WeakReference<>(video);
        held.watcher = () -> {
            long now = SystemClock.uptimeMillis();
            if (now - held.lastLook >= LOOK_EVERY_MS) {
                held.lastLook = now;
                View alive = target.get();
                if (alive != null) {
                    try {
                        rescan(alive, held);
                    } catch (Throwable failure) {
                        Logger.printException(() -> "Could not look for the cover picture", failure);
                    }
                }
            }
            return true;
        };
        ViewTreeObserver observer = page.getViewTreeObserver();
        if (observer != null) observer.addOnPreDrawListener(held.watcher);
        held.page = new WeakReference<>(page);
    }

    private static void stopWatching(Held held) {
        View page = held.page == null ? null : held.page.get();
        if (page != null && held.watcher != null) {
            ViewTreeObserver observer = page.getViewTreeObserver();
            if (observer != null) observer.removeOnPreDrawListener(held.watcher);
        }
        held.page = null;
        held.watcher = null;
    }

    /** Gives the pictures back their drawing. Cheap when nothing was ever hidden. */
    static void clear(View video) {
        if (video == null || HELD.isEmpty()) return;
        Held held = HELD.remove(video);
        if (held == null) return;
        try {
            video.removeOnLayoutChangeListener(held);
            stopWatching(held);
            if (!SmartStretch.supported()) return;
            for (WeakReference<View> reference : held.hidden) {
                View cover = reference.get();
                if (cover != null) Gpu.show(cover);
            }
            held.hidden.clear();
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not bring the cover picture back", failure);
        }
    }

    /** How far up from the video view to look for the page that holds it, if it is not found by name. */
    private static final int LEVELS_UP = 5;
    private static final int MAX_NODES = 300;
    private static final int MAX_DEPTH = 10;
    private static final int DUMP_NODES = 110;

    /** Where one search of a page is going. */
    private static final class Search {
        final int rootWidth;
        final int rootHeight;
        final List<View> found = new ArrayList<>();
        final StringBuilder dump = new StringBuilder();
        int nodes;
        int dumped;

        Search(int rootWidth, int rootHeight) {
            this.rootWidth = rootWidth;
            this.rootHeight = rootHeight;
        }
    }

    /**
     * The page the video view belongs to: the view named like a cell root if there is one above it,
     * otherwise a few levels up. Everything the cover could be sits somewhere under it.
     */
    static View pageOf(View video) {
        View root = video;
        ViewParent parent = video.getParent();
        int up = 0;
        while (parent instanceof View && up < LEVELS_UP) {
            View view = (View) parent;
            root = view;
            if (view.getClass().getSimpleName().contains("CellRootView")) break;
            parent = view.getParent();
            up++;
        }
        return root;
    }

    private static void rescan(View video, Held held) {
        View root = pageOf(video);
        SmartStretch.Surfaces surfaces = SmartStretch.surfacesUnder(root);
        boolean any = surfaces.texture || surfaces.surface;
        Search search = new Search(root.getWidth(), root.getHeight());
        search.dump.append("page ").append(root.getClass().getSimpleName()).append(' ')
                .append(root.getWidth()).append('x').append(root.getHeight())
                .append(any ? "" : " (no video surface in it, so left alone)").append(" | ");
        walk(root, root, 0, search);
        if (search.nodes >= 3) lastSeen = search.dump.toString();
        if (!any || search.rootWidth <= 0 || search.rootHeight <= 0) {
            // A photo post, or a video whose surface is not there yet: nothing is hidden for it.
            for (WeakReference<View> reference : held.hidden) {
                View cover = reference.get();
                if (cover != null) Gpu.show(cover);
            }
            held.hidden.clear();
            return;
        }
        for (View cover : search.found) {
            boolean known = false;
            for (WeakReference<View> reference : held.hidden) {
                if (reference.get() == cover) {
                    known = true;
                    break;
                }
            }
            if (known) continue;
            Gpu.hide(cover);
            held.hidden.add(new WeakReference<>(cover));
            HIDDEN.incrementAndGet();
            lastHidden = describe(cover);
        }
    }

    /** A view and the few views above it, as "SmartImageView 720x1608 in RelativeLayout < FrameLayout". */
    private static String describe(View view) {
        StringBuilder text = new StringBuilder();
        text.append(view.getClass().getSimpleName()).append(' ')
                .append(view.getWidth()).append('x').append(view.getHeight());
        ViewParent parent = view.getParent();
        for (int level = 0; level < 4 && parent instanceof View; level++) {
            text.append(level == 0 ? " in " : " < ")
                    .append(((View) parent).getClass().getSimpleName());
            parent = ((View) parent).getParent();
        }
        return text.toString();
    }

    private static void walk(View view, View root, int depth, Search search) {
        if (search.nodes >= MAX_NODES) return;
        search.nodes++;
        boolean cover = view != root && isCover(view, search);
        if (cover) search.found.add(view);
        // The empty stubs TikTok inflates on demand fill the page and say nothing, so they are
        // counted but not listed.
        boolean empty = view.getVisibility() == View.GONE && view.getWidth() == 0 && view.getHeight() == 0;
        if (!empty && search.dumped < DUMP_NODES) {
            search.dumped++;
            for (int indent = 0; indent < depth; indent++) search.dump.append('.');
            search.dump.append(view.getClass().getSimpleName()).append(' ')
                    .append(view.getWidth()).append('x').append(view.getHeight());
            int visibility = view.getVisibility();
            search.dump.append(visibility == View.VISIBLE ? "" : visibility == View.INVISIBLE ? " invisible" : " gone");
            if (view.getAlpha() < 0.99f) search.dump.append(" alpha ").append(view.getAlpha());
            if (cover) search.dump.append(" (hidden)");
            search.dump.append("; ");
        }
        if (view instanceof ViewGroup && depth < MAX_DEPTH) {
            ViewGroup group = (ViewGroup) view;
            for (int index = 0; index < group.getChildCount(); index++) {
                walk(group.getChildAt(index), root, depth + 1, search);
            }
        }
    }

    /** An image view about as big as the page: the still picture, not a button, an avatar or an icon. */
    private static boolean isCover(View view, Search search) {
        if (!(view instanceof ImageView)) return false;
        if (search.rootWidth <= 0 || search.rootHeight <= 0) return false;
        return view.getWidth() >= search.rootWidth * 0.6
                && view.getHeight() >= search.rootHeight * 0.6;
    }

    /** The calls that need API 33, kept where nothing loads them on an older phone. */
    @TargetApi(Build.VERSION_CODES.TIRAMISU)
    private static final class Gpu {
        static void hide(View view) {
            view.setRenderEffect(RenderEffect.createRuntimeShaderEffect(new RuntimeShader(SHADER), "content"));
        }

        static void show(View view) {
            view.setRenderEffect(null);
        }
    }
}
