/*
 * Copyright 2026 Hushfeed contributors
 * https://github.com/SysAdminDoc/hushfeed
 *
 * Built on icysymmetra/tiktok-patches-for-morphe (GPL-3.0).
 */
package app.morphe.extension.tiktok.interaction;

import android.annotation.TargetApi;
import android.graphics.RenderEffect;
import android.graphics.RuntimeShader;
import android.os.Build;
import android.os.SystemClock;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicLong;

import app.morphe.extension.shared.Logger;

/**
 * Stops the still picture TikTok puts up for a moment before each video starts from being drawn,
 * so the video is the only thing on screen as you scroll.
 *
 * <p>The picture is a large image view somewhere in the video's page, not necessarily beside the
 * video itself. The page is searched once when a video is set up, and again before each frame for
 * a very short while after, because TikTok fills in parts of a page a moment after it binds it.
 * Then the watching stops: nothing runs per frame while a video plays, and a page that is not
 * being bound costs nothing.
 *
 * <p>The cover is not removed or hidden, because TikTok shows, fades and hides it on its own
 * schedule and would undo anything written to its visibility or alpha. It is given a view effect
 * that draws nothing instead, which TikTok never touches. That effect is built once and shared.
 *
 * <p>Only a page with a video surface in it is looked at, so a photo post, whose pictures are the
 * post, is left alone. Needs Android 13 (API 33); on an older phone nothing here changes.
 */
final class CoverHider {
    private CoverHider() {}

    private static final String SHADER =
            "uniform shader content;\n"
                    + "half4 main(float2 p) {\n"
                    + "    return content.eval(p) * 0.0;\n"
                    + "}\n";

    /** How far up from a view the page that holds it is looked for. */
    private static final int LEVELS_UP = 8;
    private static final int MAX_NODES = 300;
    private static final int MAX_DEPTH = 10;
    private static final int DUMP_NODES = 110;

    /** The page is looked at before every frame this long after a video is set up... */
    private static final long EVERY_FRAME_MS = 300;
    /** ...then once more at this point, and then the watching ends. */
    private static final long LAST_LOOK_MS = 600;
    /** A video is set up through several views at once; the page is only searched once per this long. */
    private static final long SAME_BIND_MS = 150;
    /** The report's description of the page is rebuilt at most this often, because building it costs. */
    private static final long DUMP_EVERY_MS = 2000;

    /** One video page: the covers made invisible in it and whether it is being watched. */
    private static final class Page {
        final List<WeakReference<View>> hidden = new ArrayList<>();
        long boundAt;
        long lastScan;
        boolean watching;
        ViewTreeObserver.OnPreDrawListener watcher;
        WeakReference<View> root;
    }

    private static final Map<View, Page> PAGES = Collections.synchronizedMap(new WeakHashMap<>());

    /** Pictures made invisible so far, and what sat around the last video, for the report. */
    static final AtomicLong HIDDEN = new AtomicLong();
    private static volatile String lastSeen = "";
    private static volatile String lastHidden = "";
    private static volatile long lastDumpAt;

    static String lastSeen() {
        return lastSeen;
    }

    static String lastHidden() {
        return lastHidden;
    }

    private static boolean supported() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU;
    }

    /**
     * The page the view belongs to: the view named like a cell root if there is one above it,
     * otherwise a few levels up. Everything the cover could be sits somewhere under it.
     */
    static View pageOf(View view) {
        View root = view;
        ViewParent parent = view.getParent();
        int up = 0;
        while (parent instanceof View && up < LEVELS_UP) {
            View above = (View) parent;
            root = above;
            if (above.getClass().getSimpleName().contains("CellRootView")) break;
            parent = above.getParent();
            up++;
        }
        return root;
    }

    /**
     * Hides the cover when the video this view draws was resized, and gives it back when it was
     * not. Only a view with the video surface in or under it decides: TikTok hands the same
     * result to the cover and the subtitle layers, and they must not undo what the video's own
     * view decided.
     */
    static void follow(View view, boolean hide) {
        if (view == null) return;
        try {
            if (!holdsVideo(view, 0)) return;
            if (hide) apply(view);
            else clear(view);
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not follow the video's size", failure);
        }
    }

    private static boolean holdsVideo(View view, int depth) {
        if (view instanceof TextureView || view instanceof SurfaceView) return true;
        if (depth > 3 || !(view instanceof ViewGroup)) return false;
        ViewGroup group = (ViewGroup) view;
        for (int index = 0; index < group.getChildCount(); index++) {
            if (holdsVideo(group.getChildAt(index), depth + 1)) return true;
        }
        return false;
    }

    /** Looks for the cover in this view's page and hides it. Never throws. */
    static void apply(View view) {
        if (view == null) return;
        try {
            if (!supported()) return;
            long now = SystemClock.uptimeMillis();
            View root = pageOf(view);
            Page page = PAGES.get(root);
            if (page == null) {
                page = new Page();
                page.root = new WeakReference<>(root);
                PAGES.put(root, page);
            }
            // The hook runs for several of the page's views in one bind; one search covers them all.
            if (now - page.boundAt < SAME_BIND_MS && page.boundAt != 0) return;
            page.boundAt = now;
            scan(root, page, now);
            watch(root, page);
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not hide the cover picture", failure);
        }
    }

    /** Gives the covers their drawing back. Cheap when nothing was ever hidden. */
    static void clear(View view) {
        if (view == null || PAGES.isEmpty()) return;
        try {
            Page page = PAGES.remove(pageOf(view));
            if (page == null) return;
            stopWatching(page);
            if (!supported()) return;
            for (WeakReference<View> reference : page.hidden) {
                View cover = reference.get();
                if (cover != null) Gpu.show(cover);
            }
            page.hidden.clear();
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not bring the cover picture back", failure);
        }
    }

    /**
     * Looks at the page before each of the next few frames, because a cover can come into it a
     * moment after the video was set up. The listener takes itself off when the time is up, so
     * nothing runs while the video plays.
     */
    private static void watch(View root, Page page) {
        if (page.watching) return;
        ViewTreeObserver observer = root.getViewTreeObserver();
        if (observer == null) return;
        page.watcher = () -> {
            try {
                long now = SystemClock.uptimeMillis();
                long since = now - page.boundAt;
                View alive = page.root.get();
                if (alive == null || since > LAST_LOOK_MS + 100) {
                    stopWatching(page);
                    return true;
                }
                boolean frame = since <= EVERY_FRAME_MS;
                boolean last = since >= LAST_LOOK_MS && page.lastScan < page.boundAt + LAST_LOOK_MS;
                if (frame || last) scan(alive, page, now);
            } catch (Throwable failure) {
                Logger.printException(() -> "Could not look for the cover picture", failure);
            }
            return true;
        };
        observer.addOnPreDrawListener(page.watcher);
        page.watching = true;
    }

    private static void stopWatching(Page page) {
        if (!page.watching) return;
        View root = page.root == null ? null : page.root.get();
        if (root != null && page.watcher != null) {
            ViewTreeObserver observer = root.getViewTreeObserver();
            if (observer != null) observer.removeOnPreDrawListener(page.watcher);
        }
        page.watching = false;
        page.watcher = null;
    }

    /** What one look at a page found. */
    private static final class Look {
        final int rootWidth;
        final int rootHeight;
        final List<View> covers = new ArrayList<>();
        /** Null when the report's description is not being built this time. */
        final StringBuilder dump;
        boolean surface;
        int nodes;
        int dumped;

        Look(int rootWidth, int rootHeight, StringBuilder dump) {
            this.rootWidth = rootWidth;
            this.rootHeight = rootHeight;
            this.dump = dump;
        }
    }

    private static void scan(View root, Page page, long now) {
        page.lastScan = now;
        boolean describe = now - lastDumpAt >= DUMP_EVERY_MS;
        Look look = new Look(root.getWidth(), root.getHeight(), describe ? new StringBuilder() : null);
        if (look.dump != null) {
            look.dump.append("page ").append(root.getClass().getSimpleName()).append(' ')
                    .append(root.getWidth()).append('x').append(root.getHeight()).append(" | ");
        }
        walk(root, root, 0, look);
        if (look.dump != null) {
            if (!look.surface) look.dump.insert(0, "(no video surface in it, so left alone) ");
            if (look.nodes >= 3) {
                lastSeen = look.dump.toString();
                lastDumpAt = now;
            }
        }
        if (!look.surface || look.rootWidth <= 0 || look.rootHeight <= 0) {
            // A photo post, or a video whose surface is not there yet: nothing is hidden for it.
            if (!page.hidden.isEmpty() && !look.surface) {
                for (WeakReference<View> reference : page.hidden) {
                    View cover = reference.get();
                    if (cover != null) Gpu.show(cover);
                }
                page.hidden.clear();
            }
            return;
        }
        for (View cover : look.covers) {
            boolean known = false;
            for (WeakReference<View> reference : page.hidden) {
                if (reference.get() == cover) {
                    known = true;
                    break;
                }
            }
            if (known) continue;
            Gpu.hide(cover);
            page.hidden.add(new WeakReference<>(cover));
            HIDDEN.incrementAndGet();
            lastHidden = describe(cover);
        }
    }

    private static void walk(View view, View root, int depth, Look look) {
        if (look.nodes >= MAX_NODES) return;
        look.nodes++;
        if (view instanceof TextureView || view instanceof SurfaceView) look.surface = true;
        boolean cover = view != root && isCover(view, look);
        if (cover) look.covers.add(view);
        if (look.dump != null && look.dumped < DUMP_NODES) {
            // The empty stubs TikTok inflates on demand fill the page and say nothing.
            boolean empty = view.getVisibility() == View.GONE && view.getWidth() == 0 && view.getHeight() == 0;
            if (!empty) {
                look.dumped++;
                for (int indent = 0; indent < depth; indent++) look.dump.append('.');
                look.dump.append(view.getClass().getSimpleName()).append(' ')
                        .append(view.getWidth()).append('x').append(view.getHeight());
                int visibility = view.getVisibility();
                look.dump.append(visibility == View.VISIBLE ? "" : visibility == View.INVISIBLE ? " invisible" : " gone");
                if (cover) look.dump.append(" (hidden)");
                look.dump.append("; ");
            }
        }
        if (view instanceof ViewGroup && depth < MAX_DEPTH) {
            ViewGroup group = (ViewGroup) view;
            for (int index = 0; index < group.getChildCount(); index++) {
                walk(group.getChildAt(index), root, depth + 1, look);
            }
        }
    }

    /** An image view about as big as the page: the still picture, not a button, an avatar or an icon. */
    private static boolean isCover(View view, Look look) {
        if (!(view instanceof ImageView)) return false;
        if (look.rootWidth <= 0 || look.rootHeight <= 0) return false;
        return view.getWidth() >= look.rootWidth * 0.6 && view.getHeight() >= look.rootHeight * 0.6;
    }

    /** A view and the few views above it, as "SmartImageView 720x1608 in RelativeLayout < FrameLayout". */
    private static String describe(View view) {
        StringBuilder text = new StringBuilder();
        text.append(view.getClass().getSimpleName()).append(' ')
                .append(view.getWidth()).append('x').append(view.getHeight());
        ViewParent parent = view.getParent();
        for (int level = 0; level < 4 && parent instanceof View; level++) {
            text.append(level == 0 ? " in " : " < ").append(((View) parent).getClass().getSimpleName());
            parent = ((View) parent).getParent();
        }
        return text.toString();
    }

    /** The calls that need API 33, kept where nothing loads them on an older phone. */
    @TargetApi(Build.VERSION_CODES.TIRAMISU)
    private static final class Gpu {
        /** Built once: compiling the shader takes long enough to be felt when it is done for every video. */
        private static RenderEffect hidden;

        static void hide(View view) {
            if (hidden == null) {
                hidden = RenderEffect.createRuntimeShaderEffect(new RuntimeShader(SHADER), "content");
            }
            view.setRenderEffect(hidden);
        }

        static void show(View view) {
            view.setRenderEffect(null);
        }
    }
}
