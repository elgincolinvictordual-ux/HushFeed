/*
 * Copyright 2026 Hushfeed contributors
 * https://github.com/SysAdminDoc/hushfeed
 *
 * Built on icysymmetra/tiktok-patches-for-morphe (GPL-3.0).
 */
package app.morphe.extension.tiktok.interaction;

import android.annotation.TargetApi;
import android.graphics.RenderEffect;
import android.graphics.RuntimeShader;
import android.os.Build;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;

import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicLong;

import app.morphe.extension.shared.Logger;

/**
 * The non-linear half of "Edge-warp stretch".
 *
 * <p>{@link VideoFit} sizes the video view to the whole window, exactly as Stretch does, which
 * pulls every row of the picture taller by the same amount. This re-samples the video view's own
 * picture through a small shader so the pull is not the same everywhere: the middle of the video
 * keeps its shape, and the stretching is pushed toward the top and bottom edges, where the
 * caption and the buttons already sit. A slice is also cropped off each side, the way a TV's
 * panoramic mode does, so the edges have less to absorb.
 *
 * <p>It goes on the video view itself and nothing above it, and only when that view is drawn
 * through a {@code TextureView}; a {@code SurfaceView} is composited on its own and a view
 * effect cannot reach it. The shader is compiled once per video view and only its numbers change
 * after that, because compiling it for every video made each video start stutter. Every
 * coordinate it reads is kept inside the picture. Where any of this is missing nothing here
 * changes what is drawn, and the video is left as plain Stretch made it.
 */
final class EdgeWarp {
    private EdgeWarp() {}

    /** The least crop: the middle keeps its shape and the edges take up the rest. */
    static final double MIN_ZOOM = 1.04;

    /**
     * The stretch left to spread after the crop. Past this the crop takes more of the difference
     * instead, so the curve stays increasing.
     */
    static final double TARGET_STRETCH = 1.25;

    /**
     * How far from the window's shape a video may be, as a ratio, for the warp to take it. A 9:16
     * video on a 20:9 phone is about a quarter off. Past this the crop that keeps the edges
     * bearable would take a visible slice off each side, so those videos keep TikTok's size.
     */
    static final double MAX_SHAPE = 1.45;

    /** Below this the video is already the window's shape and there is nothing to spread. */
    private static final double NEGLIGIBLE = 1.001;

    /**
     * How tall each row of the picture comes out compared with the video's own shape, when the
     * view is made {@code width} by {@code height} for a video of {@code videoWidth} by
     * {@code videoHeight}. Plain stretch makes it the same number everywhere.
     */
    static double stretchOf(int videoWidth, int videoHeight, int width, int height) {
        if (videoWidth <= 0 || videoHeight <= 0 || width <= 0 || height <= 0) return 1.0;
        return (height / (double) width) / (videoHeight / (double) videoWidth);
    }

    /**
     * The numbers the shader needs: {@code a}, {@code b} and {@code zoom}, or null when there is
     * nothing to spread.
     *
     * <p>Let {@code t} be a position down the window, 0 at the top and 1 at the bottom, and
     * {@code warp(t)} the position in the stretched picture that is drawn there. The slope of
     * {@code warp} is {@code a - b * (2t - 1)^2}: steepest in the middle, where it equals the
     * stretch left after the crop so the middle comes out with its own shape, and flattening
     * toward the ends, where the picture is spread out more. {@code b} is chosen so that
     * {@code warp(1) = 1}, which is what makes the picture cover the window exactly.
     */
    static double[] curve(int videoWidth, int videoHeight, int width, int height) {
        double stretch = stretchOf(videoWidth, videoHeight, width, height);
        if (stretch <= NEGLIGIBLE) return null;
        double zoom = Math.max(MIN_ZOOM, stretch / TARGET_STRETCH);
        double left = stretch / zoom;
        if (left <= NEGLIGIBLE) return new double[]{1.0, 0.0, stretch}; // the crop alone covers it
        return new double[]{left, 3.0 * (left - 1.0), zoom};
    }

    /** Where in the stretched picture the row drawn at {@code t} comes from, both as fractions. */
    static double warp(double t, double a, double b) {
        double u = 2.0 * t - 1.0;
        return a * t - b * (u * u * u + 1.0) / 6.0;
    }

    private static final String SHADER =
            "uniform shader content;\n"
                    + "uniform float2 size;\n"
                    + "uniform float a;\n"
                    + "uniform float b;\n"
                    + "uniform float zoom;\n"
                    + "half4 main(float2 p) {\n"
                    + "    float t = clamp(p.y / size.y, 0.0, 1.0);\n"
                    + "    float u = 2.0 * t - 1.0;\n"
                    + "    float y = (a * t - b * (u * u * u + 1.0) / 6.0) * size.y;\n"
                    + "    float x = size.x * 0.5 + (p.x - size.x * 0.5) / zoom;\n"
                    + "    return content.eval(float2(clamp(x, 0.5, size.x - 0.5),\n"
                    + "                               clamp(y, 0.5, size.y - 0.5)));\n"
                    + "}\n";

    /** What one video view carries: its shader, built once, and the numbers it was last given. */
    private static final class State implements View.OnLayoutChangeListener {
        final WeakReference<View> view;
        int videoWidth;
        int videoHeight;
        int width;
        int height;
        Object shader;
        int setWidth;
        int setHeight;
        double setA = Double.NaN;
        double setB;
        double setZoom;

        State(View view, int videoWidth, int videoHeight, int width, int height) {
            this.view = new WeakReference<>(view);
            this.videoWidth = videoWidth;
            this.videoHeight = videoHeight;
            this.width = width;
            this.height = height;
        }

        @Override
        public void onLayoutChange(View changed, int left, int top, int right, int bottom,
                                   int oldLeft, int oldTop, int oldRight, int oldBottom) {
            int w = right - left;
            int h = bottom - top;
            if (w <= 0 || h <= 0 || (w == setWidth && h == setHeight)) return;
            try {
                set(changed, this);
            } catch (Throwable failure) {
                Logger.printException(() -> "Could not update the edge warp", failure);
            }
        }
    }

    private static final Map<View, State> STATES = Collections.synchronizedMap(new WeakHashMap<>());

    /** Times the effect was changed, and how many of those views had a TextureView or only a SurfaceView. */
    static final AtomicLong APPLIED = new AtomicLong();
    static final AtomicLong TEXTURE = new AtomicLong();
    static final AtomicLong SURFACE = new AtomicLong();

    static boolean supported() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU;
    }

    /**
     * Puts the effect on the video view, sized for the view being {@code width} by {@code height},
     * or takes it off when there is nothing to spread. Never throws: a picture left as plain
     * stretch is the fallback for every way this can fail.
     */
    static void apply(View view, int videoWidth, int videoHeight, int width, int height) {
        if (view == null) return;
        try {
            if (!supported()) return;
            if (!hasTexture(view)) {
                // TikTok sizes more than the video this way (the cover, the subtitles). Only the
                // view that is drawn through a TextureView is warped.
                if (hasSurface(view)) SURFACE.incrementAndGet();
                clear(view);
                return;
            }
            State state = STATES.get(view);
            if (state == null) {
                state = new State(view, videoWidth, videoHeight, width, height);
                view.addOnLayoutChangeListener(state);
                STATES.put(view, state);
            } else {
                state.videoWidth = videoWidth;
                state.videoHeight = videoHeight;
                state.width = width;
                state.height = height;
            }
            set(view, state);
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not put the edge warp on the video", failure);
        }
    }

    private static void set(View view, State state) {
        double[] curve = curve(state.videoWidth, state.videoHeight, state.width, state.height);
        if (curve == null) {
            if (!Double.isNaN(state.setA)) {
                Gpu.remove(view);
                state.setA = Double.NaN;
            }
            return;
        }
        int width = Math.max(1, view.getWidth() > 0 ? view.getWidth() : state.width);
        int height = Math.max(1, view.getHeight() > 0 ? view.getHeight() : state.height);
        if (state.setWidth == width && state.setHeight == height && state.setA == curve[0]
                && state.setB == curve[1] && state.setZoom == curve[2]) {
            return; // nothing changed since it was last set
        }
        if (state.shader == null) state.shader = Gpu.compile(SHADER);
        Gpu.set(view, state.shader, width, height, curve);
        state.setWidth = width;
        state.setHeight = height;
        state.setA = curve[0];
        state.setB = curve[1];
        state.setZoom = curve[2];
        APPLIED.incrementAndGet();
        TEXTURE.incrementAndGet();
    }

    /** Takes the effect off a view and forgets it. Cheap when nothing was ever put on. */
    static void clear(View view) {
        if (view == null || STATES.isEmpty()) return;
        State state = STATES.remove(view);
        if (state == null) return;
        try {
            view.removeOnLayoutChangeListener(state);
            if (supported()) Gpu.remove(view);
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not take the edge warp off the video", failure);
        }
    }

    private static boolean hasTexture(View view) {
        return find(view, true, 0);
    }

    private static boolean hasSurface(View view) {
        return find(view, false, 0);
    }

    private static boolean find(View view, boolean texture, int depth) {
        if (texture ? view instanceof TextureView : view instanceof SurfaceView) return true;
        if (depth > 8 || !(view instanceof ViewGroup)) return false;
        ViewGroup group = (ViewGroup) view;
        for (int index = 0; index < group.getChildCount(); index++) {
            if (find(group.getChildAt(index), texture, depth + 1)) return true;
        }
        return false;
    }

    /** The calls that need API 33, kept where nothing loads them on an older phone. */
    @TargetApi(Build.VERSION_CODES.TIRAMISU)
    private static final class Gpu {
        static Object compile(String source) {
            return new RuntimeShader(source);
        }

        static void set(View view, Object shader, int width, int height, double[] curve) {
            RuntimeShader runtime = (RuntimeShader) shader;
            runtime.setFloatUniform("size", (float) width, (float) height);
            runtime.setFloatUniform("a", (float) curve[0]);
            runtime.setFloatUniform("b", (float) curve[1]);
            runtime.setFloatUniform("zoom", (float) curve[2]);
            view.setRenderEffect(RenderEffect.createRuntimeShaderEffect(runtime, "content"));
        }

        static void remove(View view) {
            view.setRenderEffect(null);
        }
    }
}
