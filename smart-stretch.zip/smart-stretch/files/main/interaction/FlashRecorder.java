/*
 * Copyright 2026 Hushfeed contributors
 * https://github.com/SysAdminDoc/hushfeed
 *
 * Built on icysymmetra/tiktok-patches-for-morphe (GPL-3.0).
 */
package app.morphe.extension.tiktok.interaction;

import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import app.morphe.extension.shared.Logger;

/**
 * Writes down what the video page does in the two seconds after a video is set up, so the
 * diagnostic report can say what the still picture before a video is and when it goes.
 *
 * <p>Every frame in that window the page is looked over for the video view and for any view
 * about half the page's size or more. Whenever one of them changes size, visibility, alpha,
 * scale or position, or an image changes what it shows or how it is scaled, one line is added
 * with the time since the video was set up. Nothing here changes what is drawn.
 */
final class FlashRecorder {
    private FlashRecorder() {}

    private static final long WINDOW_MS = 2000;
    private static final long EXTEND_MS = 600;
    private static final int MAX_NODES = 300;
    private static final int MAX_DEPTH = 10;
    private static final int MAX_EVENTS = 70;
    private static final int MAX_CHARS = 4500;
    private static final int KEEP = 4;

    private static final class Timeline {
        final long start;
        final String header;
        final StringBuilder events = new StringBuilder();
        final Map<Integer, String> last = new LinkedHashMap<>();
        int count;
        long until;

        Timeline(long start, String header) {
            this.start = start;
            this.header = header;
            this.until = start + WINDOW_MS;
        }

        String text() {
            return header + (count == 0 ? " | nothing changed" : " | " + events);
        }
    }

    private static final class Recording implements ViewTreeObserver.OnPreDrawListener {
        final WeakReference<View> video;
        Timeline current;
        WeakReference<View> page;

        Recording(View video) {
            this.video = new WeakReference<>(video);
        }

        @Override
        public boolean onPreDraw() {
            try {
                Timeline timeline = current;
                if (timeline == null) return true;
                long now = SystemClock.uptimeMillis();
                if (now > timeline.until) {
                    finish(timeline);
                    current = null;
                    return true;
                }
                View view = video.get();
                if (view != null) sample(view, timeline, now);
            } catch (Throwable failure) {
                Logger.printException(() -> "Could not record the video page", failure);
            }
            return true;
        }
    }

    private static final Map<View, Recording> RECORDINGS = Collections.synchronizedMap(new WeakHashMap<>());
    private static final List<String> DONE = new ArrayList<>();

    /** The latest timelines, newest first, one line each, for the report. */
    static synchronized List<String> timelines() {
        List<String> lines = new ArrayList<>();
        for (int index = DONE.size() - 1; index >= 0; index--) {
            lines.add("Flash timeline " + (DONE.size() - index) + " (newest first): " + DONE.get(index));
        }
        return lines;
    }

    private static synchronized void finish(Timeline timeline) {
        DONE.add(timeline.text());
        while (DONE.size() > KEEP) DONE.remove(0);
    }

    /** Called each time the video view is set up. Starts a recording, or extends the one running. */
    static void start(View video) {
        if (video == null) return;
        try {
            Recording recording = RECORDINGS.get(video);
            if (recording == null) {
                recording = new Recording(video);
                RECORDINGS.put(video, recording);
            }
            long now = SystemClock.uptimeMillis();
            if (recording.current != null && now <= recording.current.until) {
                recording.current.until = Math.max(recording.current.until, now + EXTEND_MS);
            } else {
                if (recording.current != null) finish(recording.current);
                View page = CoverHider.pageOf(video);
                recording.current = new Timeline(now, "video view " + name(video) + " made "
                        + video.getWidth() + "x" + video.getHeight() + " in page "
                        + name(page) + " " + page.getWidth() + "x" + page.getHeight());
            }
            View page = CoverHider.pageOf(video);
            View watched = recording.page == null ? null : recording.page.get();
            if (watched != page) {
                if (watched != null) {
                    ViewTreeObserver old = watched.getViewTreeObserver();
                    if (old != null) old.removeOnPreDrawListener(recording);
                }
                ViewTreeObserver observer = page.getViewTreeObserver();
                if (observer != null) observer.addOnPreDrawListener(recording);
                recording.page = new WeakReference<>(page);
            }
        } catch (Throwable failure) {
            Logger.printException(() -> "Could not start recording the video page", failure);
        }
    }

    private static String name(View view) {
        return view.getClass().getSimpleName() + "#" + Integer.toHexString(System.identityHashCode(view) & 0xffff);
    }

    private static void sample(View video, Timeline timeline, long now) {
        View page = CoverHider.pageOf(video);
        Map<Integer, String> seen = new LinkedHashMap<>();
        Map<Integer, View> views = new HashMap<>();
        int[] nodes = {0};
        look(page, page, video, 0, page.getWidth(), page.getHeight(), seen, views, nodes);
        long at = now - timeline.start;
        for (Map.Entry<Integer, String> entry : seen.entrySet()) {
            String before = timeline.last.get(entry.getKey());
            if (before == null) {
                add(timeline, at, "+" + entry.getValue());
            } else if (!before.equals(entry.getValue())) {
                add(timeline, at, before + " => " + entry.getValue());
            }
        }
        for (Map.Entry<Integer, String> entry : timeline.last.entrySet()) {
            if (!seen.containsKey(entry.getKey())) add(timeline, at, "-" + entry.getValue());
        }
        timeline.last.clear();
        timeline.last.putAll(seen);
    }

    private static void add(Timeline timeline, long at, String text) {
        if (timeline.count >= MAX_EVENTS || timeline.events.length() > MAX_CHARS) return;
        timeline.count++;
        timeline.events.append('t').append(at).append("ms ").append(text).append("; ");
    }

    private static void look(View view, View page, View video, int depth, int pageWidth,
                             int pageHeight, Map<Integer, String> seen, Map<Integer, View> views,
                             int[] nodes) {
        if (nodes[0]++ >= MAX_NODES) return;
        boolean large = view != page && pageWidth > 0 && pageHeight > 0
                && view.getWidth() >= pageWidth * 0.5 && view.getHeight() >= pageHeight * 0.5;
        if (view == video || large) {
            seen.put(System.identityHashCode(view), "d" + depth + " " + describe(view, view == video));
        }
        if (view instanceof ViewGroup && depth < MAX_DEPTH) {
            ViewGroup group = (ViewGroup) view;
            for (int index = 0; index < group.getChildCount(); index++) {
                look(group.getChildAt(index), page, video, depth + 1, pageWidth, pageHeight, seen, views, nodes);
            }
        }
    }

    private static String describe(View view, boolean isVideo) {
        StringBuilder text = new StringBuilder();
        text.append(isVideo ? "VIDEO " : "").append(name(view)).append(' ')
                .append(view.getWidth()).append('x').append(view.getHeight());
        int visibility = view.getVisibility();
        text.append(visibility == View.VISIBLE ? " shown" : visibility == View.INVISIBLE ? " invisible" : " gone");
        if (view.getAlpha() < 0.99f) text.append(" alpha").append(String.format("%.2f", view.getAlpha()));
        if (Math.abs(view.getScaleX() - 1f) > 0.01f || Math.abs(view.getScaleY() - 1f) > 0.01f) {
            text.append(" scale").append(String.format("%.2f", view.getScaleX())).append('x')
                    .append(String.format("%.2f", view.getScaleY()));
        }
        if (Math.abs(view.getTranslationX()) > 1f || Math.abs(view.getTranslationY()) > 1f) {
            text.append(" moved").append((int) view.getTranslationX()).append(',').append((int) view.getTranslationY());
        }
        if (view instanceof ImageView) {
            ImageView image = (ImageView) view;
            Drawable drawable = image.getDrawable();
            text.append(" image ").append(drawable == null ? "none"
                    : drawable.getIntrinsicWidth() + "x" + drawable.getIntrinsicHeight())
                    .append(' ').append(image.getScaleType());
        }
        if (view instanceof TextureView) {
            text.append(" texture ").append(((TextureView) view).isAvailable() ? "ready" : "waiting");
        }
        return text.toString();
    }
}
